<?php $__env->startSection('content'); ?>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Acme&display=swap');

* {
margin: 0;
padding: 0;
}

:root {
--blue: #2cd4f3;
--orange: #faa469;
--black: #000000;
--white: #FFFFFF;
}

body {
background: url(/img/8.jpg);
background-size: cover;
background-repeat: no-repeat;
-webkit-user-select: none;
font-family: 'Acme', sans-serif;
}

nav {
background-color: var(--orange);
height: 5rem;
box-shadow: 0 0 50px 0;
}

nav img {
max-width: 6.25rem;
max-height: 6.25rem;
border-radius: 100%;
margin: 1.5rem 0 0 2rem;
}

nav p {
margin: -6.8rem 0 0 13rem;
font-size: 1.8rem;
}


#container {
background-color: var(--blue);
max-width: 500px;
width: 100%;
margin: 6rem 0 0 8rem;
}

#login_title {
text-align: center;
padding: 1.5rem 1rem 0.7rem 1rem;
}

#login_title h1 {
font-size: 2rem;
}

#login_title p {
font-size: 1.2rem;
}

#container form {
padding: 2rem 0 2rem 5rem;
}

#container form label {
font-size: 1.3rem;
font-weight: 400
}

form input {
padding: 0.6rem 0.7rem 0.6rem 0.6rem;
border-radius: 5px;
max-width: 300px;
width: 100%;
margin: 0 0 1rem 0;
font-size: 1rem;
}

form #login {
max-width: 200px;
width: 100%;
margin: 2rem 0 0 2.5rem;
background-color: var(--orange);
padding: 0.6rem 0.7rem 0.6rem 0.6rem;
font-size: 1.063rem;
font-weight: bold;
border-radius: 0.313rem;
font-family: 'Acme', sans-serif;
}

form #back {
max-width: 100px;
width: 100%;
margin: 2rem 0 0 0;
background-color: var(--orange);
padding: 0.6rem 0.7rem 0.6rem 0.6rem;
font-size: 1.063rem;
font-weight: bold;
border-radius: 0.313rem;
font-family: 'Acme', sans-serif;
}

form #login:hover {
letter-spacing: 0.063rem;
}

@media(max-width: 750px) {
body {
   background-image: none;
   background-color: var(--blue);
}

nav p {
   margin: -6.8rem 0 0 13rem;
   font-size: 1.4rem;

}

#container {
   background-color: transparent;
   max-width: 500px;
   width: 100%;
   margin: 4rem 0 0 8rem;
}

#login_title {
   text-align: center;
   padding: 1.5rem 1rem 1rem 1rem;
}

#login_title h1 {
   font-size: 2rem;
}

#login_title p {
   font-size: 1.2rem;
}

#container form label {
   font-size: 1.3rem;
   font-weight: 400
}

}
.card
{
margin-top:5%;
flex: 0 0 auto;
width: 100%;
background-color:transparent;
border:none;
}
</style>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <h1 class="card-header"style=" background-color:transparent;color:#000;border-bottom:none;text-align:center;"><?php echo e(__('Register')); ?></h1>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="row mb-3">
                            <label for="name" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Name')); ?></label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>

                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="email" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Email Address')); ?></label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="password" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password">

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-end"><?php echo e(__('Confirm Password')); ?></label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                            </div>
                        </div>

                        <div class="row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn"style="background-color:#faa469;">
                                    <?php echo e(__('Register')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\VirEd\resources\views/auth/register.blade.php ENDPATH**/ ?>