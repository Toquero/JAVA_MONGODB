

<?php $__env->startSection('content'); ?>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Acme&display=swap');
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;700&display=swap');

        *,
        *:after,
        *:before {
            box-sizing: border-box;
        }

        body {
            background: url(/img/8.jpg);
            background-size: cover;
            background-repeat: no-repeat;
            -webkit-user-select: none;
            font-family: 'Acme', sans-serif;

        }

        img {
            max-width: 100%;
            display: block;
        }

        input {
            appearance: none;
            border-radius: 0;
        }

        .card {
        
          
            width: 40%;
            background-color: #FFF;
            border-radius: 10px;
            padding:1rem;
           
        }

        .card-image {
            border-radius: 8px;
            overflow: hidden;
            padding-bottom: 15%;
            background-color: #faa469;
            background-repeat: no-repeat;
            background-position: 0 5%;
            position: relative;
        }

        .card-heading {
            position: absolute;
            left: 10%;
            top: 15%;
            right: 10%;
            font-size: 1.75rem;
            font-weight: 700;
            color: #735400;
            line-height: 1.222;

            small {
                display: block;
                font-size: .75em;
                font-weight: 400;
                margin-top: .25em;
            }
        }

        .card-form {
            padding:1rem ;
        }

        .input {
            display: flex;
            flex-direction: column-reverse;
            position: relative;
            padding-top: 1.5rem;

            &+.input {
                margin-top: 1.5rem;
            }
        }

        .input-label {
            color: #8597a3;
            position: absolute;
            top: 1.5rem;
            transition: .25s ease;
        }

        .input-field {
            border: 0;
            z-index: 1;
            background-color: transparent;
            border-bottom: 2px solid #eee;
            font: inherit;
            font-size: 1.125rem;
            padding: .25rem 0;

            &:focus,
            &:valid {
                outline: 0;
                border-bottom-color: #8597a3;

                &+.input-label {
                    color: #8597a3;
                    transform: translateY(-1.5rem);
                }
            }
        }

        .action {
            margin-top: 2rem;
        }

        .continueBtn {
            font: inherit;
            font-size: 1.25rem;
            padding: 1em;
            width: 100%;
            font-weight: 500;
            background-color: #8597a3;
            border-radius: 6px;
            color: #FFF;
            border: 0;

            &:focus {
                outline: 0;
            }
        }

        .card-info {
            padding: 1rem 1rem;
            text-align: center;
            font-size: .875rem;
            color: #8597a3;

            a {
                display: block;
                color: #8597a3;
                text-decoration: none;
            }
        }
        .field-wrap{
            font: inherit;
            font-size: 1.25rem;
            padding: .5rem;
            width: 28%;
            background-color: #8597a3;
            border-radius: 6px;
            color: #FFF;
            border: 0;

            &:focus {
                outline: 0;
            }
        }
    </style>

    <body>
        <div class="container">
            <!-- code here -->
            <div class="card">
                <div class="card-image">
                    <h2 class="card-heading">
                        Get started
                        <small>Let us create your account</small>
                    </h2>
                </div>
                <form class="card-form" method="post" action="<?php echo e(url('addUser')); ?>">
                    <?php echo e(csrf_field()); ?> <br>
                    <div class="top-row">
                        <div class="field-wrap">
                            <label for="sex" id="sex">
                               <span class="req"></span>
                            </label>
                            <select name="gender" id="gender" required autocomplete="off"style=" background-color: #8597a3;">
                                <option value="">-GENDER-</option>
                                <option value="Male">MALE</option>
                                <option value="Female">FEMALE</option>
                            </select>
                        </div>
                        <div class="input">
                            <label>
                                Full Name
                            </label>
                            <input type="text" name="name" id="name" />
                        </div>
                        <div class="input">
                            <label>
                                Age
                            </label>
                            <input type="text" name="age" id="age" />
                        </div>
                        <div class="input">
                            <label>
                               Favorite Subject 
                            </label>
                            <input type="text" name=" FavoriteSubject" id=" FavoriteSubject" />
                        </div>
                        <div class="input">
                            <label>
                                School
                            </label>
                            <input type="text" name="school" id="school" />
                        </div>

                        <div class="input">
                            <label>
                                Grade Level
                            </label>
                            <input type="text" name="grade_level" id="grade_level" />
                        </div>

                        <div class="input">
                            <label>
                                Email Address<span class="req"></span>
                            </label>
                            <input name="email" type="email" required autocomplete="off" />
                        </div>

                        <div class="action">
                            <button class="continueBtn">Get Started</button></a>
                        </div>
                </form>
                <div class="card-info">
                    <p>By filling this form you are agreeing to our <a href="#">Terms and Conditions</a></p>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\VirEd\resources\views//UserDetails.blade.php ENDPATH**/ ?>