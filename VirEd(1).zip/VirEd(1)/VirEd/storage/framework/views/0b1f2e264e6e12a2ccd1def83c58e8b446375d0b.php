<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Index Page</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>

<body>


    <div class="container">
        <br />
        <?php if(\Session::has('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e(\Session::get('success')); ?></p>
            </div><br />
        <?php endif; ?>
        <table class="table table-striped">
            <thead>
                <h1>Birth Certification Requests</h1>
                <tr>
                    <th>Sex</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Middle Name</th>
                    <th>Birthdate</th>
                    <th>Place of Birth</th>
                    <th>ID Presented</th>
                    <th>Father's First Name</th>
                    <th>Father's Middle Name</th>
                    <th>Father's Last Name</th>
                    <th>Mother's First Name</th>
                    <th>Mother's Middle Name</th>
                    <th>Mother's Last Name</th>
                    <th>Late Registration?</th>
                    <th>Purpose</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>

                <?php $__currentLoopData = $birth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $birth): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($birth->sex); ?></td>
                        <td><?php echo e($birth->fname); ?></td>
                        <td><?php echo e($birth->mname); ?></td>
                        <td><?php echo e($birth->lname); ?></td>
                        <td><?php echo e($birth->birthdate); ?></td>
                        <td><?php echo e($birth->birthplace); ?></td>
                        <td><?php echo e($birth->idtype); ?></td>
                        <td><?php echo e($birth->ffname); ?></td>
                        <td><?php echo e($birth->fmname); ?></td>
                        <td><?php echo e($birth->flname); ?></td>
                        <td><?php echo e($birth->mfname); ?></td>
                        <td><?php echo e($birth->mmname); ?></td>
                        <td><?php echo e($birth->mlname); ?></td>
                        <td><?php echo e($birth->lateReg); ?></td>
                        <td><?php echo e($birth->purpose); ?></td>
                        <td><?php echo e($birth->status); ?></td>

                        <td><a href=<?php echo e('edit/' . $birth['id']); ?> class="btn btn-warning">Update</a>
                            
                        </td>

                        
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>


    </div>
</body>

</html>
<?php /**PATH C:\Users\User\laravelmongodb\resources\views/birthindex.blade.php ENDPATH**/ ?>