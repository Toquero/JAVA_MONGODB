<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <form method="post" action="<?php echo e(url('addUser')); ?>">
        <?php echo e(csrf_field()); ?> <br>
        <h3>Your Information</h3>
        <div class="top-row">
            <div class="field-wrap">
                <label for="sex" id="sex">
                    Gender<span class="req"></span>
                </label>
                <select name="gender" id="gender" required autocomplete="off">
                    <option value="">-GENDER-</option>
                    <option value="Male">MALE</option>
                    <option value="Female">FEMALE</option>
                </select>
            </div>
            <div class="field-wrap">
                <label>
                    Full Name
                </label>
                <input type="text" name="name" id="name" />
            </div>

            <div class="field-wrap">
                <label>
                    Grade Level
                </label>
                <input type="text" name="grade_level" id="grade_level" />

            </div>

            <div class="field-wrap">
                <label>
                    Email Address<span class="req"></span>
                </label>
                <input name="email" type="email" required autocomplete="off" />
            </div>
        </div>

        <div class="verifyBtn">
            <button class="continueBtn">Submit</button></a>
        </div>

    </form>
</body>

</html>
<?php /**PATH C:\Users\User\VirEd\resources\views/UserDetails.blade.php ENDPATH**/ ?>