<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"
        integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="icon" href="/img/logo.jpg">
    <title>VirEd Landing Page</title>
</head>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Acme&display=swap');

:root {
    --main-color: #09adff;
    --black: #13131a;
    --bg: #010103;
    --border: .1rem solid rgba(111, 242, 254, 0.3);
    --box-shadow: 0 .5rem 1.5rem rgba(211, 173, 127, .9);
}

* {
    font-family: 'Acme', sans-serif;
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    outline: none;
    border: none;
    text-decoration: none;
    transition: .2s linear;
}

html {
    font-size: 62.5%;
    overflow-x: hidden;
    -ms-scroll-chaining: 9rem;
    scroll-behavior: smooth;
}

html::-webkit-scrollbar {
    width: .8rem;
}

html::-webkit-scrollbar-track {
    background: transparent;
}

html::-webkit-scrollbar-thumb {
    background: #fff;
    border-radius: 5rem;
}

body {
    background-color: #23ccff;
}

section {
    padding: 2rem 7%;
}

.heading {
    text-align: center;
    color: #fff;
    text-transform: uppercase;
    padding-bottom: 3.5rem;
    font-size: 4rem;
    background-color: #000000;
}

.heading span {
    color: var(--main-color);
}

.btn {
    margin-top: 1rem;
    display: inline-block;
    padding: .9rem 3rem;
    font-size: 1.7rem;
    color: rgb(0, 0, 0);
    background-color: #ffffff;
    cursor: pointer;
    border-radius: 5px;
    font-family: 'Acme', sans-serif;
}

.btn:hover {
    letter-spacing: .2rem;
}

header nav {
    background:#faa469;
    display: flex;
    align-items: center;
    box-shadow: 0 0 50px 0;
    border-bottom: var(--border);
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 1000;
    text-shadow: #000000, 10px;
}

nav img {
    max-width: 10rem;
    max-height: 10rem;
    border-radius: 100%;
    /* margin:0.5rem 3rem 0.3rem 8rem; */
    margin: 1.8rem 2rem -3.5rem 8rem;
}

nav ul li {
    display: inline-block;


}

nav ul li a {
    color: rgb(0, 0, 0);
    padding: 0 1.8rem 0 2.6rem;
    font-size: 2.2rem;
    font-weight: bold;
}

nav ul li:hover {
    font-size: 1.4rem;
    color: var(--main-color);
    border-bottom: .1rem solid var(--main-color);
    padding-bottom: .5rem;
}

header nav .search-form {
    background: #ffffff;
    width: 45rem;
    height: 4.4rem;
    display: flex;
    align-items: center;
    border-radius: 5px;
    padding: 0 0 0 1.2rem;
    margin: 0 0 0 10rem;
}

header nav .search-form input {
    font-size: 1.4rem;
    width: 100%;
    text-transform: none;
    color: var(--black);
    border: none;
    outline: none;

}

header nav .fa-search {
    color: var(--black);
    cursor: pointer;
    font-size: 2.5rem;
    margin: 0.2rem 0.5rem 0 0;
}

header nav .user_icon .fa-user {
    font-size: 3.5rem;
    margin: 0 0 0 2rem;
}

.login-form-container {
    display: flex;
    align-items: center;
    justify-content: center;
    background: rgba(255, 255, 255, .9);
    position: fixed;
    top: 0;
    right: -105%;
    z-index: 10000;
    height: 100%;
    width: 100%;
}

.login-form-container.active {
    right: 0;
}

.login-form-container form {
    background: #fff;
    border: var(--border);
    width: 40rem;
    padding: 2rem;
    box-shadow: var(--box-shadow);
    border-radius: .5rem;
    margin: 2rem;
}

.login-form-container form h3 {
    font-size: 2.5rem;
    text-transform: uppercase;
    color: var(--black);
    text-align: center;
}

.login-form-container form span {
    display: block;
    font-size: 1.5rem;
    padding-top: 1rem;
}

.login-form-container form .box {
    width: 100%;
    margin: .7rem 0;
    font-size: 1.6rem;
    border: var(--border);
    border-radius: .5rem;
    padding: 1rem 1.2rem;
    color: var(--black);
    text-transform: none;
}

.login-form-container form .checkbox {
    display: flex;
    align-items: center;
    gap: .5rem;
    padding: 1rem 0;
}

.login-form-container form .checkbox label {
    font-size: 1.5rem;
    color: var(--light-color);
    cursor: pointer;
}

.login-form-container form .btn {
    text-align: center;
    width: 100%;
    margin: 1.5rem 0;
}

.login-form-container form p {
    padding-top: .8rem;
    color: var(--light-color);
    font-size: 1.5rem;
}

.login-form-container form p a {
    color: var(--green);
    text-decoration: underline;
}

.login-form-container #close-login-btn {
    position: absolute;
    top: 1.5rem;
    right: 2.5rem;
    font-size: 5rem;
    color: var(--black);
    cursor: pointer;
}

.home {
    background-color: #23ccff;
    background-size: cover;
    background-position: center;
}

.home .row {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 1.6rem;
    grid-template-columns: repeat(auto-fit, minmax(17rem, 1fr));
}

.home .row .content {
    flex: 1 1 42rem;
    padding: 2px;
    margin-top: 150px;
}

.home .row .content h1 {
    color: var(--black);
    font-size: 8rem;
    font-family: 'Acme', sans-serif;
}

.home .row .content p {
    color: var(--light-color);
    font-size: 1.5rem;
    line-height: 2;
    padding: 1rem 0;
    font-family: 'Acme', sans-serif;
    align-items: justify;
}

.icons-container {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(22rem, 1fr));
    gap: 1.3rem;
}


.icons-container .content h3 {
    font-size: 2.2rem;
    color: var(--black);
    padding-bottom: .5rem;
    padding-bottom: 2px;
}

.icons-container .content p {
    font-size: 1.4rem;
    color: var(--light-color);
    padding-bottom: 2px;



}

.swiper-button-next,
.swiper-button-prev {
    border: var(--border-hover);
    height: 4rem;
    width: 4rem;
    color: var(--black);
    background: #fff;
}

.swiper-button-next::after,
.swiper-button-prev::after {
    font-size: 2rem;
}

.swiper-button-next:hover,
.swiper-button-prev:hover {
    background: var(--black);
    color: #fff;
}


.arrivals .swiper arrivals-slider .box {
    display: flex;
    align-items: center;
    gap: 1.5rem;
    padding: 2rem 1rem;
    border: var(--border);
    margin: 1rem 0;
}

.arrivals .arrivals-slider .box:hover {
    border: var(--border-hover);
}

.arrivals .arrivals-slider .box .image img {
    height: 15rem;
}

.arrivals .arrivals-slider .box .content h3 {
    font-size: 2rem;
    color: var(--black);
}

.arrivals .arrivals-slider .box .content .price {
    font-size: 2.2rem;
    color: var(--black);
    padding-bottom: .5rem;
}

.arrivals .arrivals-slider .box .content .price span {
    font-size: 1.5rem;
    color: var(--light-color);
    text-decoration: line-through;
}

.arrivals .arrivals-slider .box .content .stars i {
    font-size: 1.5rem;
    color: var(--green);
}

.footer {
    background: var(--black);
    text-align: center;
}

.footer .box-container {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(23rem, 1fr));
    gap: 1.5rem;
}

.footer .box-container .box h3 {
    font-size: 2.5rem;
    padding: 1rem 0;
    color: var(--main-color);
}

.footer .box-container .box a {
    display: block;
    font-size: 1.5rem;
    padding: 1rem 0;
    color: var(--main-color);
}

.footer .box-container .box a i {
    padding-right: .5rem;
}

.footer .box-container .box a:hover i {
    padding-right: 2rem;
}

/*read more */

.img-fluid {
    width: 100%;
    height: auto;
    box-sizing: border-box;
    object-fit: cover;
}

#featured>div.row.mx-auto.container>nav>ul>li.page-item.active>a {
    background-color: #000;
}

#featured>div.row.mx-auto.container>nav>ul>li:nth-child(n):hover>a {
    background-color: #d11111ec;
    color: #fff;
}

.pagination a {
    color: #000;
}

hr {
    margin-top: 0;
    width: 50px;
    height: 3px;
    background-color: #d11111ec;
}

.star i {
    font-size: 1.2rem;
    color: rgb(252, 214, 0);
}

.star {
    padding: 10px 0;
}

.product {
    cursor: pointer;
    margin-bottom: 2rem;
}

.product img {
    transition: 0.3s ease all;
}

.product:hover img {
    opacity: 0.7;
}

.product .buy-btn {
    background: #d11111ec;
    transform: translateY(20px);
    opacity: 0;
    transition: 0.3s ease;
}

.product:hover .buy-btn {
    transform: translateY(0);
    opacity: 1;
}



.container {
    display: inline-block;
}

.typed-out {
    overflow: hidden;
    border-right: .15em solid#faa469;
    white-space: nowrap;
    animation:
        typing 5s forwards;
    font-size: 2rem;
    width: 0;
    font-family: 'Acme', sans-serif;
}

@keyframes typing {
    from {
        width: 0
    }

    to {
        width: 100%
    }
}

.twelve h1 {
  font-size: 30px; 
  font-weight:700;  
  letter-spacing:1px; 
  text-transform:uppercase; 
  width:160px; 
  text-align:center; 
  margin:auto; 
  white-space:nowrap; 
  padding-bottom:13px;
  font-family: 'Acme', sans-serif;
}
.twelve h1:before {
    background-color: #c50000;
    content: '';
    display: block;
    height: 3px;
    width: 75px;
    margin-bottom: 5px;
}

</style>

<body>
    <header>
        <nav>
            <a href="/homepage"><img src="/img/logo.jpg" alt="logo"></a>
            <ul>
                <li><a href="/landing">Home</a></li>
                <li><a  href="/library">Library</a></li>
                <li><a href="/quizzes">Quizzes</a></li>
                <li><a href="/contacts">Contact</a></li>
                <li><a href="/blogs">Blogs</a></li>

            </ul>
            <div class="search-form">
                <input type="search" id="search-box" placeholder="Search here...">
                <label for="search-box" class="fas fa-search"></label>
            </div>
        </nav>
    </header>

    <!-- home section starts  -->

    <section class="home" id="home">

        <div class="row">

            <div class="content">
                <h1>Welcome to VirEd</h1>
                <div class="container"> <br><br>
                    <div class="typed-out"><i> Online Education is the new age change that students are adapting.</i>
                    </div>
                </div>
                <p>The benefits of online education are endless. It has been considered a boon for the education sector.
                    It has helped students learn efficiently by gaining resources and attending lectures online.
                    It is deemed cheaper and reliable as students can learn and practice independently without pressure
                    and stiff competition like in real classrooms. Online Education provides well-established
                    information
                    via the curriculum and other resources from every sphere of life.</p>
                <a href="/readmore" class="btn">FEATURED</a>

            </div>

            <div>
                <img src="img/children1.png" class="children1" alt="" style="padding: 5px; margin-top: 100px;">
            </div>

        </div>

    </section>

    <!-- home section ense  -->

    <!-- icons section starts  -->

    <section class="icons-container">

        <div>
            <img src="img/english.png" alt="" style="padding: 1px; margin-top: 50px; width: 100px; height: 100px;">
            <div class="content">
                <h3>MATH</h3>
                <p><a href="/math" class="btn">Read more</a></p>
            </div>
        </div>

        <div>
            <img src="img/filipino.png" alt="" style="padding: 1px; margin-top: 50px; width: 100px; height: 100px;">
            <div class="content">
                <h3>SCIENCE</h3>
                <p><a href="/science" class="btn">Read more</a></p>
            </div>
        </div>

        <div>
            <img src="img/maths.png" alt="" style="padding: 1px; margin-top: 50px; width: 100px; height: 100px;">
            <div class="content">
                <h3>ENGLISH</h3>
                <p><a href="/english" class="btn">Read more</a></p>
            </div>
        </div>

        <div>
            <img src="img/science.png" alt="" style="padding: 1px; margin-top: 50px; width: 100px; height: 100px;">
            <div class="content">
                <h3>FILIPINO</h3>
                <p><a href="/filipino" class="btn">Read more</a></p>
            </div>
        </div>

        <div>
            <img src="img/story.png" alt=""
                style="padding-block-end: 2px; margin-top: 50px; width: 100px; height: 100px;">
            <div class="content">
                <h3>STORIES</h3>
                <p><a href="/stories" class="btn">Read more</a></p>
            </div>
        </div>
    </section>
    <!-- icons section ends -->


    <!-- arrivals section starts  -->

    <section id="clothes" class="my-5">
        <div class="twelve" style=" margin-top: 100px;">
            <h1>New Books to Explore</h1>
        </div>
        <br> <br> <br>
        <div class="row mx-auto container-fluid">
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img class="img-fluid" src="https://i.pinimg.com/564x/83/58/cd/8358cdffc33f304343707914f53fc61e.jpg"
                    alt="">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">STORY BOOK</h5>
                <h4 class="p-name">ENGLISH</h4>
                <button class="buy-btn"></button>
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img class="img-fluid" src="https://i.pinimg.com/564x/34/29/4f/34294f94dd6ddc37a44c3b7b716b0987.jpg"
                    alt="">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">STORY BOOK</h5>
                <h4 class="p-name">ENGLISH</h4>
                <button class="buy-btn"></button>
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img class="img-fluid" src="https://i.pinimg.com/564x/fc/32/97/fc3297efa18950fddeb645ecfcb82b55.jpg"
                    alt="">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">STORY BOOK</h5>
                <h4 class="p-name">ENGLISH</h4>
                <button class="buy-btn"></button>
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img class="img-fluid" src="https://i.pinimg.com/236x/f0/9a/ef/f09aefb5ac902bf3a57cc04fef1a366a.jpg"
                    alt="">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">STORY BOOK</h5>
                <h4 class="p-name">ENGLISH</h4>
                <a href=""><button class="buy-btn"></button></a>
            </div>
        </div>
    </section>

    <!-- arrivals section ends -->

    <!-- footer section starts  -->

    <section class="footer">

        <div class="box-container">
            <div class="box">
                <h3>quick links</h3>
                <a href="/landing"> <i class="fas fa-arrow-right"></i> home </a>
                <a href="/library"> <i class="fas fa-arrow-right"></i> Library </a>
                <a href="/contacts"> <i class="fas fa-arrow-right"></i> Contacts </a>
                <a href="/blogs"> <i class="fas fa-arrow-right"></i> Blogs </a>
            </div>

            <div class="box">
                <h3>contact info</h3>
                <a href="#"> <i class="fas fa-phone"></i> +123-456-7890 </a>
                <a href="#"> <i class="fas fa-phone"></i> +111-222-3333 </a>
                <a href="#"> <i class="fas fa-envelope"></i> VirEd@gmail.com </a>
                <a href="#"> <i class="fas fa-envelope"></i> VirEdPhilippines </a>
            </div>

            <div class="box">
                <h3>SNS</h3>
                <a href="https://facebook.com"> <i class="fab fa-facebook-f"></i> facebook </a>
                <a href="https://twitter.com"> <i class="fab fa-twitter"></i> twitter </a>
                <a href="https://instagram.com"> <i class="fab fa-instagram"></i> instagram </a>
                <a href="https://linkedin.com"> <i class="fab fa-linkedin"></i> linkedin </a>
            </div>
        </div>
        <div class="box">
            <footer style="color: white ;float: right;">
                <p>© Copyright 2022 Vired</p>
            </footer>
        </div>
    </section>
</body>
<script src="<?php echo e(asset('js/landing.js')); ?>"></script>

</html><?php /**PATH C:\Users\Student.Admin\VirEd(1)\VirEd\resources\views/library.blade.php ENDPATH**/ ?>