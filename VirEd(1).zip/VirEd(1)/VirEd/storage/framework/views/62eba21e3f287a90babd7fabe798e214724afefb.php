<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/quizzes.css')); ?>">
    <link rel="icon" href="/img/logo.jpg">
    <title>VirEd Quizzes</title>
</head>
<body>
    <header>
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Acme&display=swap');

:root {
    --main-color: #09adff;
    --black: #13131a;
    --bg: #010103;
    --border: .1rem solid rgba(111, 242, 254, 0.3);
    --box-shadow: 0 .5rem 1.5rem rgba(211, 173, 127, .9);
}

* {
    font-family: 'Acme', sans-serif;
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    outline: none;
    border: none;
    text-decoration: none;
    transition: .2s linear;
}


header nav {
    background: #faa469;
    display: flex;
    align-items: center;
    box-shadow: 0 0 50px 0;
    border-bottom: var(--border);
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 1000;
    text-shadow: #000000, 10px;
}

nav img {
    max-width: 6.5rem;
    max-height: 6.5rem;
    border-radius: 100%;
    margin: 1.6rem 2rem -2.8rem 3rem;
}

nav ul li {
    display: inline-block;
}

nav ul li a {
    color: rgb(0, 0, 0);
    padding: 0 1rem 0 1.6rem;
    font-size: 1.5rem;
    font-weight: bold;
    font-family: 'Acme', sans-serif;
}

nav ul li:hover {
    font-size: 1.4rem;
    color: var(--main-color);
    border-bottom: .1rem solid var(--main-color);
    padding-bottom: .5rem;
}

header nav .search-form {
    background: #ffffff;
    width: 26rem;
    height: 2.8rem;
    display: flex;
    align-items: center;
    border-radius: 5px;
    padding: 0 0 0 1.2rem;
    margin: 0 0 0 5rem;
}

header nav .search-form input {
    font-size: 1.4rem;
    width: 100%;
    text-transform: none;
    color: var(--black);
    border: none;
    outline: none;

}

header nav .fa-search {
    color: var(--black);
    cursor: pointer;
    font-size: 2rem;
    margin: 0.2rem 0.5rem 0 0;
}

header nav .user_icon .fa-user {
    font-size: 2.2rem;
    margin: 0 0 0 1.7rem;
}

.footer {
    background: var(--black);
    text-align: center;
}

.footer .box-container {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(23rem, 1fr));
    gap: 1.5rem;
}

.footer .box-container .box h3 {
    font-size: 2.5rem;
    padding: 1rem 0;
    color: var(--main-color);
}

.footer .box-container .box a {
    display: block;
    font-size: 1.5rem;
    padding: 1rem 0;
    color: var(--main-color);
}

.footer .box-container .box a i {
    padding-right: .5rem;
}

.footer .box-container .box a:hover i {
    padding-right: 2rem;
}

h1 {
    font-size: 300%;
    color:#000000;
    padding-top: 7rem;
}

h2 {
    font-size: 300%;
    color: darkcyan;
}

.panel {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    background-color: whitesmoke;
    width: 70%;
    border-radius: 20px;
    background-color: #faa469;
    border:solid 5px #000000
}

.question-container {
    margin: 10px;
    padding: 5px;
    width: 50vw;
    font-size: x-large;
    text-align: center;
    color: maroon;
    border-radius: 5px;
    font-family: Impact;
    font-size: 200%;
}

.result {
    margin: 10px;
    padding: 5px;
    width: 80vw;
    text-align: center;
    font-size: 50px;
}

.option-container {
    display: flex;
    justify-content: space-around;
    margin: 10px;
    padding: 5px;
    width: 70vw;
    color: maroon;
    font-family: Impact;
    font-size: 70%;
}

.option {
    padding: 10px;
    width: 12vw;
    font-size: 200%;
    background-color: pink;
    border-radius: 25%;

}

.option:hover {
    background-color: rgb(22, 7, 245);
}

.navigation {
    width: 80vw;
    margin: 10px;
    padding: 5px;
    display: flex;
    justify-content: space-around;
}

.evaluate,
.next,
.previous {
    width: 13vw;
    padding: 5px;
    font-size: 150%;
    border-radius: 20px;
    color: maroon;
    font-family: Impact;

}

.evaluate {
    background-color: #fff;
}

.evaluate:hover {
    background-color: #3fafff;
}

.next {
    color: black;
    background-color: #bf3325;
}

.next:hover {
    background-color: lightgoldenrodyellow;
}

.previous {
    color: black;
    background-color: #bf3325;
}

.previous:hover {
    background-color: lightgoldenrodyellow;
}

.pera {
    font-size: 1.1rem;
    color: rgb(75, 61, 61);
    font-family: 'Poppins', sans-serif;
}

#image {
    max-width: 50vw;
    max-height: 50vh;
}
        </style>
        <nav>
            <a href="/homepage"><img src="/img/logo.jpg" alt="logo"></a>
            <ul>
                <li><a href="/landing">Home</a></li>
                <li><a href="/library">Library</a></li>
                <li><a class="nav-link active text-danger" href="/quizzes">Quizzes</a></li>
                <li><a href="/contacts">Contact</a></li>
                <li><a href="/blogs">Blogs</a></li>

            </ul>
            <div class="search-form">
                <input type="search" id="search-box" placeholder="Search here...">
                <label for="search-box" class="fas fa-search"></label>
            </div>
        </nav>
    </header>

    <center>
        <h1><b>VirEd | Quiz</b></h1>
        <h2><b>Have Fun and Learn!</b></h2>
        <br>
        <div class="panel">
            <div class="result"></div>
            <div class="question-container" id="question">
                Question goes here.
                <!-- <button class="option" onclick="" id="question"><img src="../resources/images/1.png" width="224" height="174" alt="Cat"></button> -->
            </div><br>
            <img src="/img/bees.png" style="width:30%" id="image" alt="">
            <br><br><br>
            <div class="option-container">
                <button class="option" onclick="" id="op1">option1</button>

                <button class="option" id="op2">option2</button>

                <button class="option" id="op3">option3</button>

                <button class="option" id="op4">option4</button>
            </div>
            <br><br>
            <div class="navigation">
                <button class="previous">Previous</button>
                <button class="evaluate">Submit</button>
                <button class="next">Next</button>
            </div>
            <br><br>
        </div>
    </center>

    <br><br>
    <script>
    const Questions = [{
            id: 0,
            q: "How many legs does a spider have?  ",
            img: "/img/spider.png",
            a: [{
                    text: "four",
                    isCorrect: false
                },
                {
                    text: "six",
                    isCorrect: false
                },
                {
                    text: "eight",
                    isCorrect: true
                },
                {
                    text: "three",
                    isCorrect: false
                }
            ]

        },
        {
            id: 1,
            q: "What’s the name of a place you go to see lots of animals?",
            img: "/img/zoo.png",
            a: [{
                    text: "Sea",
                    isCorrect: false,
                    isSelected: false
                },
                {
                    text: "Garden",
                    isCorrect: false
                },
                {
                    text: "Market",
                    isCorrect: false
                },
                {
                    text: "Zoo",
                    isCorrect: true
                }
            ]

        },
        {
            id: 2,
            q: "What do bees make?",
            img: "/img/bees.png",
            a: [{
                    text: "chick",
                    isCorrect: false
                },
                {
                    text: "Baby",
                    isCorrect: false
                },
                {
                    text: "Honey",
                    isCorrect: true
                },
                {
                    text: "Eggs",
                    isCorrect: false
                }
            ]
        },
        {
            id: 3,
            q: "In the nursery rhyme, Jack and Jill, what do Jack and Jill go up the hill to fetch?",
            img: "/img/water.png",
            a: [{
                    text: "Fish",
                    isCorrect: false
                },
                {
                    text: "vegetables",
                    isCorrect: false
                },
                {
                    text: "Water",
                    isCorrect: true
                },
                {
                    text: "Fruits",
                    isCorrect: false
                }
            ]
        },
        {
            id: 4,
            q: "Old MacDonald had a farm. E-I-E-I-O! And on his farm he had a cow. Which of the following sounds did his cow make?",
            img: "/img/moo.jpg",
            a: [{
                    text: "Oink!",
                    isCorrect: false
                },
                {
                    text: "Quack!",
                    isCorrect: false
                },
                {
                    text: " Moo!",
                    isCorrect: true
                },
                {
                    text: "Neigh!",
                    isCorrect: false
                }
            ]

        },
        {
            id: 5,
            q: "Which Disney movie is Elsa in?",
            img: "/img/frozen.png",
            a: [{
                    text: "Cinderilla",
                    isCorrect: false
                },
                {
                    text: "Barbie",
                    isCorrect: false
                },
                {
                    text: "Tnker Bell",
                    isCorrect: false
                },
                {
                    text: " Frozen",
                    isCorrect: true
                }
            ]

        },
        {
            id: 6,
            q: "What are the names of Cinderella’s stepsisters?",
            img: "/img/cinderilla.png",
            a: [{
                    text: "Anna and Elsa",
                    isCorrect: false
                },
                {
                    text: "Rosa and Leah",
                    isCorrect: false
                },
                {
                    text: " Anastasia and Drizella",
                    isCorrect: true
                },
                {
                    text: "Mia and Riya",
                    isCorrect: false
                }
            ]

        },
        {
            id: 7,
            q: "How many colors are in a rainbow?",
            img: "/img/rainbow.png",
            a: [{
                    text: " Seven",
                    isCorrect: true
                },
                {
                    text: "Four",
                    isCorrect: false
                },
                {
                    text: "Three",
                    isCorrect: false
                },
                {
                    text: "Five",
                    isCorrect: false
                }
            ]

        },
        {
            id: 8,
            q: "Which animal is the tallest in the world?",
            img: "/img/giraf.png",
            a: [{
                    text: "Pig",
                    isCorrect: false
                },
                {
                    text: "Cow",
                    isCorrect: false
                },
                {
                    text: "Giraffe ",
                    isCorrect: true
                },
                {
                    text: "Monkey",
                    isCorrect: false
                }
            ]

        },
        {
            id: 9,
            q: "How many sides does a triangle have?",
            img: "/img/triangle.png",
            a: [{
                    text: "Four",
                    isCorrect: false
                },
                {
                    text: " Three",
                    isCorrect: true
                },
                {
                    text: "Ten",
                    isCorrect: false
                },
                {
                    text: "One",
                    isCorrect: false
                }
            ]

        },
        {
            id: 10,
            q: "What is the name of Sleeping Beauty’s Prince?",
            img: "/img/prince.png",
            a: [{
                    text: "Prince Chris",
                    isCorrect: false
                },
                {
                    text: "Prince Arthur",
                    isCorrect: false
                },
                {
                    text: "Prince Leo",
                    isCorrect: false
                },
                {
                    text: " Prince Phillip",
                    isCorrect: true
                }

            ]
        }
    ]

    // Set start
    var start = true;

    // Iterate
    function iterate(id) {

        // Getting the result display section
        var result = document.getElementsByClassName("result");
        result[0].innerText = "";

        // Getting the question
        const question = document.getElementById("question");

        //Getting the image property
        const img = document.getElementById("image");

        // Setting the question text
        question.innerText = Questions[id].q;

        //Setting the image
        img.src = Questions[id].img;

        // Getting the options
        const op1 = document.getElementById('op1');
        const op2 = document.getElementById('op2');
        const op3 = document.getElementById('op3');
        const op4 = document.getElementById('op4');


        // Providing option text 
        op1.innerText = Questions[id].a[0].text;
        op2.innerText = Questions[id].a[1].text;
        op3.innerText = Questions[id].a[2].text;
        op4.innerText = Questions[id].a[3].text;

        // Providing the true or false value to the options
        op1.value = Questions[id].a[0].isCorrect;
        op2.value = Questions[id].a[1].isCorrect;
        op3.value = Questions[id].a[2].isCorrect;
        op4.value = Questions[id].a[3].isCorrect;

        var selected = "";

        // Show selection for op1
        op1.addEventListener("click", () => {
            op1.style.backgroundColor = "rgb(22, 7, 245)";
            op2.style.backgroundColor = "pink";
            op3.style.backgroundColor = "pink";
            op4.style.backgroundColor = "pink";
            selected = op1.value;
        })

        // Show selection for op2
        op2.addEventListener("click", () => {
            op1.style.backgroundColor = "pink";
            op2.style.backgroundColor = "rgb(22, 7, 245)";
            op3.style.backgroundColor = "pink";
            op4.style.backgroundColor = "pink";
            selected = op2.value;
        })

        // Show selection for op3
        op3.addEventListener("click", () => {
            op1.style.backgroundColor = "pink";
            op2.style.backgroundColor = "pink";
            op3.style.backgroundColor = "rgb(22, 7, 245)";
            op4.style.backgroundColor = "pink";
            selected = op3.value;
        })

        // Show selection for op4
        op4.addEventListener("click", () => {
            op1.style.backgroundColor = "pink";
            op2.style.backgroundColor = "pink";
            op3.style.backgroundColor = "pink";
            op4.style.backgroundColor = "rgb(22, 7, 245)";
            selected = op4.value;
        })

        // Grabbing the evaluate button
        const evaluate = document.getElementsByClassName("evaluate");

        // Evaluate method
        evaluate[0].addEventListener("click", () => {
            if (selected == "true") {
                result[0].innerHTML = "Correct! Bravo";
                result[0].style.color = "green";
            } else {
                result[0].innerHTML = "Incorrect! Keep Working";
                result[0].style.color = "red";
            }
        })
    }

    if (start) {
        iterate("0");
    }

    // Next button and method
    const next = document.getElementsByClassName('next')[0];
    var id = 0;

    next.addEventListener("click", () => {
        start = false;
        if (id < 10) {
            id++;
            iterate(id);
            console.log(id);
        }

    })

    // Next button and method
    const prev = document.getElementsByClassName('previous')[0];
    var id = 0;

    prev.addEventListener("click", () => {
        start = false;
        if (id <= 10) {
            id--;
            iterate(id);
            console.log(id);
        }

    })
    </script>

</body>

</html><?php /**PATH C:\Users\Student.Admin\VirEd(1)\VirEd\resources\views/quizzes.blade.php ENDPATH**/ ?>