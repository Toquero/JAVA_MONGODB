<!DOCTYPE html>
<html lang="en">

<?php $__env->startSection('content'); ?>

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>
        <link rel="icon" href="/img/logo.jpg">
        <link rel="stylesheet" href="<?php echo e(asset('css/landing.css')); ?>">
        <title>VirEd Landing Page</title>
        <style>
            header nav {
                background: #3fafff;
                display: flex;  
                align-items: center;
                border-bottom: var(--border);
                top: 0;
                left: 0;
                right: 0;
                z-index: 1000;
                text-shadow: #000000, 10px;
            }

            nav img {
                max-width: 10rem;
                max-height: 10rem;
                border-radius: 100%;
                /* margin:0.5rem 3rem 0.3rem 8rem; */
                margin: 2.5rem 2.5rem -3.6rem 8rem;
            }

            nav ul li {
                display: inline-block;


            }

            nav ul li a {
                color: rgb(0, 0, 0);
                padding: 0 1.9rem 0 2.3rem;
                font-size: 2.2rem;
                font-weight: bold;
                font-family: 'Acme', sans-serif;
                float: left;
                display: block;
                text-align: center;
                padding: 14px;
                text-decoration: none;
            }

            nav ul li:hover {
                font-size: 1.4rem;
                color: var(--main-color);
                border-bottom: .1rem solid var(--main-color);
                padding-bottom: .5rem;
            }

            header nav .search-form {
                background: #ffffff;
                width: 45rem;
                height: 4.4rem;
                display: flex;
                align-items: center;
                border-radius: 5px;
                padding: 0 0 0 1.2rem;
                margin: 0 0 0 6rem;
                
            }

            header nav .search-form input {
                font-size: 1.4rem;
                width: 100%;
                text-transform: none;
                color: var(--black);
                border: none;
                outline: none;

            }

            header nav .fa-search {
                color: var(--black);
                cursor: pointer;
                font-size: 2.5rem;
                margin: 0.2rem 0.5rem 0 0;
            }

            header nav .user_icon .fa-user {
                font-size: 3.5rem;
                margin: 0 0 0 2.3rem;
            }
        </style>
    </head>

    <body>

        <header>
            <nav>
                <a href="/landing"><img src="/img/logo.jpg" alt="logo"></a>
                <ul>
                    <li><a href="<?php echo e(url('/adminHome')); ?>">home</a></li>
                    <li><a href="<?php echo e(url('/home')); ?>">User View</a></li>
                    <li><a href="<?php echo e(url('/AdminDash')); ?>">Students</a></li>
                    <li><a href="<?php echo e(url('/feedback')); ?>">Feedback</a></li>

                </ul>
        </header>


        <section class="home" id="home">

            <div class="row">

                <div class="content">
                    <h3 style="font-family: Dancing Script;">A key to Early Education with one Swipe</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Magnam deserunt nostrum accusamus. Nam alias
                        sit necessitatibus, aliquid ex minima at!</p>
                    <a href="/library" class="btn">Start Learning</a>
                </div>

                <div class="swiper books-slider">
                    <div class="swiper-wrapper">
                        <a href="#" class="swiper-slide"><img src="/img/home.png" alt=""></a>
                        <a href="#" class="swiper-slide"><img src="/img/home.png" alt=""></a>
                        <a href="#" class="swiper-slide"><img src="/img/home.png" alt=""></a>
                        <a href="#" class="swiper-slide"><img src="/img/home.png" alt=""></a>
                        <a href="#" class="swiper-slide"><img src="/img/home.png" alt=""></a>
                        <a href="#" class="swiper-slide"><img src="/img/home.png" alt=""></a>
                    </div>
                </div>
            </div>
        </section>

        <section class="footer">

            <div class="box-container">

                <div class="box">
                    <h3>quick links</h3>
                    <a href="/landing"> <i class="fas fa-arrow-right"></i> home </a>
                    <a href="/library"> <i class="fas fa-arrow-right"></i> Library </a>
                    <a href="/contact"> <i class="fas fa-arrow-right"></i> Contacts </a>
                    <a href="/blogs"> <i class="fas fa-arrow-right"></i> Blogs </a>
                </div>

                <div class="box">
                    <h3>contact info</h3>
                    <a href="#"> <i class="fas fa-phone"></i> +123-456-7890 </a>
                    <a href="#"> <i class="fas fa-phone"></i> +111-222-3333 </a>
                    <a href="#"> <i class="fas fa-envelope"></i> VirEd@gmail.com </a>
                    <a href="#"> <i class="fas fa-envelope"></i> VirEdPhilippines </a>
                </div>

                <div class="box">
                    <h3>SNS</h3>
                    <a href="https://facebook.com"> <i class="fab fa-facebook-f"></i> facebook </a>
                    <a href="https://twitter.com"> <i class="fab fa-twitter"></i> twitter </a>
                    <a href="https://instagram.com"> <i class="fab fa-instagram"></i> instagram </a>
                    <a href="https://linkedin.com"> <i class="fab fa-linkedin"></i> linkedin </a>
                </div>
            </div>

            <div class="box">
                <footer style="color: white ;float: right;">
                    <p>© Copyright 2022 Vired</p>
                </footer>
            </div>
        </section>
    </body>
    <script src="<?php echo e(asset('js/landing.js')); ?>"></script>
<?php $__env->stopSection(); ?>

</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\VirEd\resources\views/landingAdmin.blade.php ENDPATH**/ ?>