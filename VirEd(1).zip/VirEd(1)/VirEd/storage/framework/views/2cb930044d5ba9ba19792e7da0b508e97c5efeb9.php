<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"
        integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/readmore.css')); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Alegreya+Sans+SC:ital@1&family=Dancing+Script:wght@700&family=Lobster&display=swap" rel="stylesheet">
    <title>Vired Online Library</title>
</head>
<style>
    header nav {
    background: #faa469;
    display: flex;
    align-items: center;
    box-shadow: 0 0 50px 0;
    border-bottom: var(--border);
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 1000;
    text-shadow: #000000, 10px;
}
nav img {
    max-width: 10rem;
    max-height: 10rem;
    border-radius: 100%;
    /* margin:0.5rem 3rem 0.3rem 8rem; */
    margin: 1.8rem 2rem -3.5rem 8rem;
}

nav ul li {
    display: inline-block;


}

nav ul li a {
    color: rgb(0, 0, 0);
    padding: 0 1.8rem 0 2.6rem;
    font-size: 2.2rem;
    font-weight: bold;
}

nav ul li:hover {
    font-size: 1.4rem;
    color: var(--main-color);
    border-bottom: .1rem solid var(--main-color);
    padding-bottom: .5rem;
}

header nav .search-form {
    background: #ffffff;
    width: 45rem;
    height: 4.4rem;
    display: flex;
    align-items: center;
    border-radius: 5px;
    padding: 0 0 0 1.2rem;
    margin: 0 0 0 10rem;
}

header nav .search-form input {
    font-size: 1.4rem;
    width: 100%;
    text-transform: none;
    color: var(--black);
    border: none;
    outline: none;

}
header nav .fa-search {
    color: var(--black);
    cursor: pointer;
    font-size: 2.5rem;
    margin: 0.2rem 0.5rem 0 0;
}
</style>
<body>
    <header>
        <nav>
            <a href="/homepage"><img src="/img/logo.jpg" alt="logo"></a>
            <ul>
                <li><a href="/landing">Home</a></li>
                <li><a  href="/library">Library</a></li>
                <li><a href="/quizzes">Quizzes</a></li>
                <li><a href="/contacts">Contact</a></li>
                <li><a href="/blogs">Blogs</a></li>

            </ul>
            <div class="search-form">
                <input type="search" id="search-box" placeholder="Search here...">
                <label for="search-box" class="fas fa-search"></label>
            </div>
        </nav>
    </header>
    <section id="featured" class="my-5 pb-5">
        <div class="twelve" style=" margin-top: 100px;">
            <h1>Featured Books <span> <br> Read books for more learnings...<br>Enjoy reading</br></span></h1>
        </div>
    
        <br> <br> <br>
        <div class="row mx-auto container">
            <div onclick="window.location.href='sproduct.html'" class="product text-center col-lg-3 col-md-4 col-12">
                <img class="img-fluid" src="https://i.pinimg.com/736x/bd/86/29/bd862919faca19c8c1de616a6e5192a5.jpg" alt="">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">THE ANT AND THE DOVE</h5>
                <h4 class="p-name">ENGLISH</h4>
               
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img class="img-fluid" src="https://i.pinimg.com/736x/14/ae/a1/14aea180304157d9bc8afa06be440e0a.jpg" alt="">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">THE LION AND THE COW</h5>
                <h4 class="p-name">ENGLISH</h4>
               
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img class="img-fluid" src="https://i.pinimg.com/736x/fb/14/79/fb14791bf21b790f8e9eba32739551e0.jpg" alt="">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">The THIRSTY CROW</h5>
                <h4 class="p-name">ENGLISH</h4>
               
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img class="img-fluid" src="https://i.pinimg.com/736x/18/3b/21/183b21834dcd76ea2077bd1c22c73086.jpg" alt="">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">THE ANT AND THE GRASSHOPPER</h5>
                <h4 class="p-name">ENGLISH</h4>
               
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img class="img-fluid" src="https://i.pinimg.com/originals/17/4d/31/174d312f1c5aaaf315a2fd7cb8026402.png" alt="">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">ALWAYS SHARE</h5>
                <h4 class="p-name">ENGLISH</h4>
               
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img class="img-fluid" src="https://i.pinimg.com/originals/81/9c/94/819c944c032d1c9c1f06800bfba31f07.png" alt="">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">NEVER LIE</h5>
                <h4 class="p-name">ENGLISH</h4>
               
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img class="img-fluid" src="https://i.ibb.co/rxfK1Zs/The-Hungry-Mouse-Story-Moral-Stories-for-Kids-in-English-Short-Stories-SK-Kids-Time-Sub-Kuch-Web.jpg" alt="">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">THE HUNGRY MOUSE</h5>
                <h4 class="p-name">ENGLISH</h4>
               
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img class="img-fluid" src="https://i.pinimg.com/474x/53/d9/57/53d957f987a3f9137bc5ca4c092451ff.jpg" alt="">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">THE CLEVER ROOSTER</h5>
                <h4 class="p-name">ENGLISH</h4>
               
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img class="img-fluid" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSDEkYx3Lm1IjZs1MsqqIYLncpgilQPbY5Qnxsay-s1ZxI17C2aEktxnRMmNsk4EzQIRtk&usqp=CAU" alt="">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">NAPULOT ANG AKLAT</h5>
                <h4 class="p-name">FILIPINO</h4>
               
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img class="img-fluid" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQOaGNy5qPG4IBwhyWq8Wt10YCH9FdG9LfRPgX6SeAAb34f7LhltJvZP2nrCrCZRkOnsSw&usqp=CAU" alt="">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">ANG KUBO</h5>
                <h4 class="p-name">FILIPINO</h4>
               
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img class="img-fluid" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcROUyxy8ZQ8V-0qts2lA9iNkXF_dki6L5ZWveRYPru81kPQRA24crUoX8PeazWgKlPppRY&usqp=CAU" alt="">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">ANG MAYA</h5>
                <h4 class="p-name">FILIPINO</h4>
               
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img class="img-fluid" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQvRgCJZdDPGsVo6UrtyPTiU9Mg3hZ5JKWtrvnPIT60Oho3E81PBXrZ8dPHSyvGkkJAg6w&usqp=CAU" alt="">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">DUMATING ANG TATAY</h5>
                <h4 class="p-name">FILIPINO</h4>
               
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img class="img-fluid" src="https://lh5.googleusercontent.com/proxy/jcXg8zJ9DNw47_nkcW0LfzsRh8HgB9epGLJN27Sqf0UIMzA75TxTmTXQry7L5kvHgzodyqu_3AvRyN8C6dH5VU9IijS281ttREyZ4hQsTagS7VF_ZgoXCLRGSA=w1200-h630-p-k-no-nu" alt="">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">ANG MUNIKA NI MIKA</h5>
                <h4 class="p-name">FILIPINO</h4>
               
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img class="img-fluid" src="https://i.pinimg.com/474x/69/d0/a7/69d0a7db2bdf12dcff4e6f0ced772507.jpg" alt="">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">ANG PALAKA SA SAPA</h5>
                <h4 class="p-name">FILIPINO</h4>
               
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img class="img-fluid" src="https://i.pinimg.com/1200x/33/9e/be/339ebee971ec7c454b87556cadc83b5e.jpg" alt="">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">NAPAGUD SILA</h5>
                <h4 class="p-name">FILIPINO</h4>
               
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img class="img-fluid" src="https://i.pinimg.com/236x/d9/ec/d1/d9ecd171d73f4ae1c60e4fa07d107a15.jpg" alt="">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">GULAY</h5>
                <h4 class="p-name">FILIPINO</h4>
               
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img class="img-fluid" src="https://i.pinimg.com/736x/c6/05/5c/c6055c2f96b75ae80d27ad920b88da91.jpg" alt="">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">FOOD CHAIN</h5>
                <h4 class="p-name">SCIENCE</h4>
               
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img class="img-fluid" src="https://i.pinimg.com/736x/76/ca/b2/76cab223ea709d3f23ccdd162f2559e9.jpg" alt="">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">GRASSLANDS</h5>
                <h4 class="p-name">SCIENCE</h4>
               
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img class="img-fluid" src="https://i.pinimg.com/736x/d5/ff/ec/d5ffec362e0d862e9e3cb6169fa81fa4.jpg" alt="">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">LIVING & NONLIVING</h5>
                <h4 class="p-name">SCIENCE</h4>
               
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img class="img-fluid" src="https://i.pinimg.com/originals/75/c3/40/75c340ae804d0c5109194130467e9648.jpg" alt="">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">LIFECYCLES</h5>
                <h4 class="p-name">SCIENCE</h4>
               
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img class="img-fluid" src="https://www.comprehension-worksheets.com/wp-content/uploads/2015/08/free-life-science-reading-comprehension-fish.jpg" alt="">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">FISH</h5>
                <h4 class="p-name">SCIENCE</h4>
               
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img class="img-fluid" src="https://i.pinimg.com/550x/bc/f2/1d/bcf21d772045a4f1eb82f9b5138f64f0.jpg" alt="">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">WETLANDS</h5>
                <h4 class="p-name">SCIENCE</h4>
               
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img class="img-fluid" src="https://www.comprehension-worksheets.com/wp-content/uploads/2015/08/free-life-science-reading-comprehension-plants.jpg" alt="">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">PLANTS</h5>
                <h4 class="p-name">SCIENCE</h4>
               
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img class="img-fluid" src="https://i.pinimg.com/736x/b2/f1/bd/b2f1bdc342167c8ed25735f8882872b2.jpg" alt="">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">MAMMALS</h5>
                <h4 class="p-name">SCIENCE</h4>
               
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img class="img-fluid" src="https://www.math-salamanders.com/image-files/3rd-grade-math-word-problems-multiplication-problems-3-1b.gif" alt="">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">MULTIPLICATION</h5>
                <h4 class="p-name">MATH</h4>
               
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img class="img-fluid" src="https://files.liveworksheets.com/def_files/2021/5/17/105171136251111459/105171136251111459001.jpg" alt="">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">ADDITION</h5>
                <h4 class="p-name">MATH</h4>
               
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img class="img-fluid" src="https://i.pinimg.com/originals/58/69/63/5869635ce7ae7648ba13e5c3ea54b7ee.png" alt="">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">WORDS PROBLEMS 1</h5>
                <h4 class="p-name">MATH</h4>
               
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img class="img-fluid" src="https://www.megaworkbook.com/images/content/Maths/Word_Problems/Addition/Maths_Word_Problems_Addition_Worksheet_07.png" alt="">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">WORDS PROBLEMS 2</h5>
                <h4 class="p-name">MATH</h4>
               
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img class="img-fluid" src="https://i.pinimg.com/originals/6c/e2/61/6ce2612c5531df7269b809758aa78cc4.png" alt="">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">SUBTRACTION</h5>
                <h4 class="p-name">MATH</h4>
               
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img class="img-fluid" src="https://files.liveworksheets.com/def_files/2020/10/11/1011204413627053/1011204413627053001.jpg" alt="">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">DIVISION</h5>
                <h4 class="p-name">MATH</h4>
               
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img class="img-fluid" src="https://www.k5learning.com/worksheets/math/grade-2-word-problems-mixed-add-subtract-a.gif" alt="">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">MIXED ADD. & SUB.</h5>
                <h4 class="p-name">MATH</h4>
               
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img class="img-fluid" src="https://static.studyladder.com/cdn/course/a7/dddae1c3596b.jpg" alt="">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">WORDS PROBLEMS 3</h5>
                <h4 class="p-name">MATH</h4>
               
            
    </section>

    <!-- footer section starts  -->

    <section class="footer">

        <div class="box-container">

            <div class="box">
                <h3>quick links</h3>
                <a href="landing"> <i class="fas fa-arrow-right"></i> home </a>
                <a href="library"> <i class="fas fa-arrow-right"></i> Libarary </a>
                <a href="contacts"> <i class="fas fa-arrow-right"></i> Contacts </a>
                <a href="blogs"> <i class="fas fa-arrow-right"></i> Blogs </a>
            </div>

            <div class="box">
                <h3>contact info</h3>
                <a href="#"> <i class="fas fa-phone"></i> +123-456-7890 </a>
                <a href="#"> <i class="fas fa-phone"></i> +111-222-3333 </a>
                <a href="#"> <i class="fas fa-envelope"></i> VirEd@gmail.com </a>
                <a href="#"> <i class="fas fa-envelope"></i> VirEdPhilippines </a>
            </div>

            <div class="box">
                <h3>SNS</h3>
                <a href="https://facebook.com"> <i class="fab fa-facebook-f"></i> facebook </a>
                <a href="https://twitter.com"> <i class="fab fa-twitter"></i> twitter </a>
                <a href="https://instagram.com"> <i class="fab fa-instagram"></i> instagram </a>
                <a href="https://linkedin.com"> <i class="fab fa-linkedin"></i> linkedin </a>
            </div>


        </div>
    
        <div class="box">
            <footer style="color: white ;float: right;">
                <p>© Copyright 2022 Vired</p>
            </footer>
        </div>
    </section>

</body>
</html><?php /**PATH C:\Users\Student.Admin\VirEd(1)\VirEd\resources\views/readmore.blade.php ENDPATH**/ ?>