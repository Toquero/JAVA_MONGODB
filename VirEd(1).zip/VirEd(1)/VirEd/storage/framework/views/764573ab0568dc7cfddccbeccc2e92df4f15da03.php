<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VirEd Landing Page</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"
        integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="stylesheet" href="<?php echo e(asset('css/contacts.css')); ?>">
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js" defer></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js" defer></script>

</head>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Acme&display=swap');

    :root {
        --main-color: #09adff;
        --black: #13131a;
        --bg: #010103;
        --border: .1rem solid rgba(111, 242, 254, 0.3);
        --box-shadow: 0 .5rem 1.5rem rgba(211, 173, 127, .9);
    }

    * {
        font-family: 'Acme', sans-serif;
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        outline: none;
        border: none;
        text-decoration: none;
        transition: .2s linear;
    }

    html {
        font-size: 62.5%;
        overflow-x: hidden;
        -ms-scroll-chaining: 9rem;
        scroll-behavior: smooth;
    }

    html::-webkit-scrollbar {
        width: .8rem;
    }

    html::-webkit-scrollbar-track {
        background: transparent;
    }

    html::-webkit-scrollbar-thumb {
        background: #fff;
        border-radius: 5rem;
    }

    body {
        background-color: #23ccff;
    }

    section {
        padding: 2rem 7%;
    }

    .heading {
        text-align: center;
        color: #fff;
        text-transform: uppercase;
        padding-bottom: 3.5rem;
        font-size: 4rem;
        background-color: #000000;
    }

    .heading span {
        color: var(--main-color);
    }

    .btn {
        margin-top: 1rem;
        display: inline-block;
        padding: .9rem 3rem;
        font-size: 1.7rem;
        color: rgb(0, 0, 0);
        background-color: #ffffff;
        cursor: pointer;
        border-radius: 5px;
    }

    .btn:hover {
        letter-spacing: .2rem;
    }

    header nav {

        background: #faa469;
        display: flex;
        align-items: center;
        box-shadow: 0 0 50px 0;
        border-bottom: var(--border);
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        z-index: 1000;
        text-shadow: #000000, 10px;
    }

    nav img {
        max-width: 10rem;
        max-height: 10rem;
        border-radius: 100%;
        /* margin:0.3rem 3rem 0.3rem 8rem; */
        margin: 2.5rem 2.5rem -3.6rem 8rem;
    }

    nav ul li {
        display: inline-block;


    }

    nav ul li a {
        color: rgb(0, 0, 0);
        padding: 0 1.5rem 0 2rem;
        font-size: 2.2rem;
        font-weight: bold;
        font-family: 'Acme', sans-serif;
    }

    nav ul li:hover {
        font-size: 1.4rem;
        color: var(--main-color);
        border-bottom: .1rem solid var(--main-color);
        padding-bottom: .5rem;
    }

    header nav .search-form {
        background: #ffffff;
        width: 42rem;
        height: 4.4rem;
        display: flex;
        align-items: center;
        border-radius: 5px;
        padding: 0 0 0 1.2rem;
        margin: 0 0 0 6rem;
    }

    header nav .search-form input {
        font-size: 1.4rem;
        width: 100%;
        text-transform: none;
        color: var(--black);
        border: none;
        outline: none;

    }

    header nav .fa-search {
        color: var(--black);
        cursor: pointer;
        font-size: 2.5rem;
        margin: 0.2rem 0.5rem 0 0;
    }

    header nav .user_icon .fa-user {
        font-size: 3.5rem;
        margin: 0 0 0 2.3rem;
    }


    .footer {
        background: var(--black);
        text-align: center;
    }

    .footer .box-container {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(23rem, 1fr));
        gap: 1.5rem;
    }

    .footer .box-container .box h3 {
        font-size: 2.5rem;
        padding: 1rem 0;
        color: var(--main-color);
    }

    .footer .box-container .box a {
        display: block;
        font-size: 1.5rem;
        padding: 1rem 0;
        color: var(--main-color);
    }

    .footer .box-container .box a i {
        padding-right: .5rem;
    }

    .footer .box-container .box a:hover i {
        padding-right: 2rem;
    }

    .wrapper {
        margin-top: 60px;
        text-align: center;
    }

    .wrapper h1 {
        font-family: 'Yatra One', cursive;
        font-size: 48px;
        color: #fff;
        margin-bottom: 25px;
    }

    .our_team {
        width: auto;
        display: flex;
        justify-content: space-around;
        flex-wrap: wrap;
    }

    .our_team .team_member {
        width: 300px;
        margin: 5px;
        background: #fff;
        padding: 30px 10px;
    }

    .our_team .team_member .member_img {
        background: #e9e5fa;
        max-width: 190px;
        width: 100%;
        height: 190px;
        margin: 0 auto;
        border-radius: 50%;
        padding: 5px;
        position: relative;
        cursor: pointer;
    }

    .our_team .team_member .member_img img {
        width: 100%;
        height: 100%;
    }

    .our_team .team_member h3 {
        text-transform: uppercase;
        font-size: 18px;
        line-height: 18px;
        letter-spacing: 2px;
        margin: 15px 0 0px;
    }

    .our_team .team_member span {
        font-size: 10px;
    }

    .our_team .team_member p {
        margin-top: 20px;
        font-size: 14px;
        line-height: 20px;
    }

    .our_team .team_member .member_img .social_media {
        position: absolute;
        top: 5px;
        left: 5px;
        background: rgba(0, 0, 0, 0.65);
        width: 95%;
        height: 95%;
        border-radius: 50%;
        display: flex;
        justify-content: center;
        align-items: center;
        transform: scale(0);
        transition: all 0.5s ease;
    }

    .our_team .team_member .member_img .social_media .item {
        margin: 0 10px;
    }

    .our_team .team_member .member_img .social_media .fab {
        color: #8c7ae6;
        font-size: 20px;
    }

    .our_team .team_member .member_img:hover .social_media {
        transform: scale(1);
    }

    .footer_get_touch_outer {
        margin-top: 80px;
    }

    .container {
        width: 95%;
        max-width: 1140px;
        margin: auto;
    }

    .grid-70-30 {
        display: grid;
        grid-template-columns: 70% 30%;
    }

    .get_form_inner {
        display: block;
        padding: 50px 40px;
        background: #fff;
        box-shadow: -4px -2px 20px -7px #cfd5df;
    }

    input[type="text"],
    input[type="text"],
    input[type="email"],
    input[type="tel"] {
        border: 1px solid #dbdbdb;
        border-radius: 2px;
        color: #333;
        height: 42px;
        padding: 0 0 0 20px;
        width: 100%;
        outline: 0;
    }

    .grid-50-50 {
        display: grid;
        grid-template-columns: 1fr 1fr;
        grid-gap: 20px;
    }

    .grid-full {
        margin: 20px 0;
    }

    textarea {
        border: 1px solid #dbdbdb;
        border-radius: 2px;
        color: #333;
        padding: 12px 0 0 20px;
        width: 100%;
        outline: 0;
        margin-bottom: 20px;
    }

    .get_form_inner_text h3 {
        color: #333;
        font-size: 26px;
        font-weight: 600;
        margin-bottom: 40px;
    }

    input[type="submit"] {
        display: inline-block;
        font-size: 16px;
        text-transform: uppercase;
        background: transparent;
        border: 2px solid;
        font-weight: 500;
        padding: 10px 20px;
        outline: 0;
        cursor: pointer;
        color: #103e65;
        transition: all 0.3s cubic-bezier(0.55, 0.055, 0.675, 0.19);
        -webkit-transition: all 0.3s cubic-bezier(0.55, 0.055, 0.675, 0.19);
        -moz-transition: all 0.3s cubic-bezier(0.55, 0.055, 0.675, 0.19);
        -ms-transition: all 0.3s cubic-bezier(0.55, 0.055, 0.675, 0.19);
        -o-transition: all 0.3s cubic-bezier(0.55, 0.055, 0.675, 0.19);
    }

    input[type="submit"]:hover {
        background-color: #f85508;
        border-color: #f85508;
        color: #fff;
    }

    .get_say_form {
        display: inline-block;
        padding: 45px 0 25px 30px;
        background: #faa469;
        position: relative;
    }

    .get_say_form h5 {
        color: #fff;
        font-size: 26px;
        margin: 0 0 40px;
    }

    ul {
        list-style: none;
        padding: 0;
        margin: 0;
    }

    .get_say_social-icn {
        display: flex;
        position: absolute;
        bottom: 40px;
    }

    .get_say_social-icn a {
        font-size: 22px;
        color: #fff;
        padding: 0 20px 0 0;
    }

    .get_say_info_sec i {
        color: #fff;
        font-size: 32px;
    }

    .get_say_info_sec>li {
        display: grid;
        grid-template-columns: 40px auto;
        align-items: center;
        margin-bottom: 40px;
    }

    .get_say_info_sec>li a {
        width: 100%;
        display: block;
        padding: 15px 25px;
        color: #fff;
        font-size: 16px;
        text-decoration: unset;
        font-weight: 500;
        background: #162b65;
        border-radius: 5px 0 0 5px;
        transition: background 0.3s cubic-bezier(0.55, 0.055, 0.675, 0.19);
        -webkit-transition: background 0.3s cubic-bezier(0.55, 0.055, 0.675, 0.19);
        -moz-transition: background 0.3s cubic-bezier(0.55, 0.055, 0.675, 0.19);
        -ms-transition: background 0.3s cubic-bezier(0.55, 0.055, 0.675, 0.19);
        -o-transition: background 0.3s cubic-bezier(0.55, 0.055, 0.675, 0.19);
    }

    .get_say_info_sec>li a:hover {
        background-color: #f85508;
    }

    .about {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        gap: 2rem;
        background-color: #fffbe9;
    }

    .about .image {
        flex: 1 1 41rem;
    }

    .about .image img {
        width: 100%;
    }

    .about .content {
        flex: 1 1 41rem;
    }

    .about .content .title {
        font-size: 4.5rem;
        color: #222222;
        font-family: 'Playball', sans-serif;
    }

    .about .content .title:after {
        content: '';
        display: block;
        margin: auto;
        height: 2px;
        animation: underline 2s infinite;
    }

    .image2 {
        display: none;
    }

    @keyframes underline {
        0% {
            width: 50%;
            background-color: #C69B7B;
        }

        100% {
            width: 100%;
            background-color: transparent;
        }
    }

    .about .content .p {
        font-size: 1.4rem;
        color: #333333;
        padding: 1rem 0;
        line-height: 2;
        text-transform: none;
    }

    .about .content #text {
        font-size: 1.4rem;
        color: #333333;
        padding: 1rem 0;
        line-height: 2;
        text-transform: none;
        display: none;
    }

    .about .content .icons-container {
        display: flex;
        flex-wrap: wrap;
        gap: 2rem;
        margin-top: 3rem;
    }

    .about .content .icons-container img {
        height: 7rem;
    }

    .about .content4 .icons-container h3 {
        padding: 1rem;
        font-size: 20px;
        font-weight: normal;
        font-family: 'Playball';
        animation: underline 4s infinite;
        border-radius: 30px;
    }

    #cont {
        margin-top: 40px;
    }



    .content4 .icons-container {
        display: flex;
    }

    .about .content4 .p {
        font-size: 1.4rem;
        color: #333333;
        padding: 1rem 0;
        line-height: 2;
        text-transform: none;
        text-indent: 100px;
    }



    *,
    *::before,
    *::after {
        margin: 0;
        paddig: 0;
        box-sizing: border-box;
        text-decoration: none;
        list-style-type: none;
        outline: none;
    }

    :root {
        /*  FONTS  */
        --font-family: sans-serif;
        --font-size: 62.5%;
        --line-height: base-line;
        /*  WIDTHS  */
        --container-width: 1366px;
    }

    html {
        font-family: var(--font-family);
        font-size: var(--font-size);
        line-height: var(--line-height);
    }

    body {
        font-size: 1.6rem;
    }

    #header,
    #main,
    #footer {
        margin: 1.5rem 0rem;
    }

    img {
        width: 100%;
        max-width: 100%;
        height: 100%;
        max-height: 100%;
        display: block;
        object-fit: cover;
    }

    .container {
        width: 100%;
        max-width: var(--container-width);
        margin: 0 auto;
        padding: 1rem;
    }

    .grid {
        display: grid;
    }

    /* STYLE HTML ELEMENTS */
    #title {
        text-align: center;
        font-size: 3rem;
        font-weight: 900;
    }

    #contain-image {
        position: relative;
        width: 100%;
        height: 50rem;
        box-shadow: 0rem 0.7rem 2rem rgba(0, 0, 0, 0.5);
        overflow: hidden;
    }

    .img {
        display: none;
    }

    #contain-button {
        position: absolute;
        bottom: 0;
        left: 50%;
        transform: translateX(-50%);
    }

    .button:hover,
    .button:focus {
        opacity: 0.5;
        transition: opacity ease-in-out 0.1s;
    }

    .active {
        opacity: 0.5;
    }

    .typewriter {
        font-family: "Poppins", sans-serif;
        font-size: 56px;
        color: #fff;
        font-weight: bold;
        position: relative;
        margin: 0;
        top: 50%;
        text-align: center;
        justify-content: center;
        transform: translateY(-50%);
    }

    .typewriter span {
        color: var(--text-color);
        text-transform: uppercase;
        padding: 10px;
        border-right: solid var(--text-color) 10px;
        animation: cursor 1s ease-in-out infinite;
    }

    @keyframes cursor {
        from {
            border-color: var(--text-color);
        }

        to {
            border-color: transparent;
        }
    }

    @media (max-width: 576px) {
        .typewriter {
            font-size: 24px;
        }
    }

    @media (max-width: 768px) {
        .typewriter {
            font-size: 36px;
        }
    }
</style>

<body>

    <header>
        <nav>
            <a href="/homepage"><img src="/img/logo.jpg" alt="logo"></a>
            <ul>
                <li><a href="/landing">Home</a></li>
                <li><a href="/library">Library</a></li>
                <li><a href="/quizzes">Quizzes</a></li>
                <li><a href="/contacts">Contact</a></li>
                <li><a href="/blogs">Blogs</a></li>

            </ul>
            <div class="search-form">
                <input type="search" id="search-box" placeholder="Search here...">
                <label for="search-box" class="fas fa-search"></label>
            </div>
        </nav>
    </header>
    <br><br><br><br><br><br>
    <header id="header" role="header">
        <section id="title-section">
            <div class="container">
                <p class="typewriter">We offer
                    <span data-text="great tutorials, free books to read, a great learning."></span>
                </p>
            </div>
        </section>
    </header>
    <main id="main" role="main">
        <section id="image-section">
            <div class="container">
                <article id="contain-image">
                    <img src="https://media.istockphoto.com/id/1297349747/photo/hot-air-balloons-flying-over-the-botan-canyon-in-turkey.jpg?b=1&s=170667a&w=0&k=20&c=1oQ2rt0FfJFhOcOgJ8hoaXA5gY4225BA4RdOP1RRBz4="
                        alt="Image" class="img" id="img1">
                    <img src="https://images.unsplash.com/photo-1623076189461-f7706b741c04?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1171&q=80"
                        alt="Image" class="img" id="img2">
                    <img src="https://images.unsplash.com/photo-1597933471507-1ca5765185d8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1171&q=80"
                        alt="Image" class="img" id="img3">
                    <img src="https://images.unsplash.com/photo-1632811484536-6f73dc0934a3?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1074&q=80"
                        alt="Image" class="img" id="img4">
                    <img src="https://images.unsplash.com/photo-1611623516688-c47bb8d43311?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1yZWxhdGVkfDV8fHxlbnwwfHx8fA%3D%3D&auto=format&fit=crop&w=500&q=60"
                        alt="Image" class="img" id="img5">
                    <img src="https://images.unsplash.com/photo-1629360021730-3d258452c425?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80"
                        alt="Image" class="img" id="img6">
                    <img src="https://images.unsplash.com/photo-1610484826917-0f101a7bf7f4?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80"
                        alt="Image" class="img" id="img7">
                    <div id="contain-button">
                        <ion-icon name="radio-button-on" class="button" id="button1"></ion-icon>
                        <ion-icon name="radio-button-on" class="button" id="button2"></ion-icon>
                        <ion-icon name="radio-button-on" class="button" id="button3"></ion-icon>
                        <ion-icon name="radio-button-on" class="button" id="button4"></ion-icon>
                        <ion-icon name="radio-button-on" class="button" id="button5"></ion-icon>
                        <ion-icon name="radio-button-on" class="button" id="button6"></ion-icon>
                        <ion-icon name="radio-button-on" class="button" id="button7"></ion-icon>
                    </div>
                </article>
            </div>
        </section>
    </main>
    <div class="wrapper">
        <h1>Meet Our Team</h1>
        <div class="our_team">
            <div class="team_member">
                <div class="member_img">
                    <img src="/img/jesa.png" alt="our_team">
                    <div class="social_media">
                        <div class="facebook item"><i class="fab fa-facebook-f"></i></div>
                        <div class="twitter item"><i class="fab fa-twitter"></i></div>
                        <div class="instagram item"><i class="fab fa-instagram"></i></div>
                    </div>
                </div>
                <h3>Jesamea Tano</h3>
                <span>Developer</span>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores maiores temporibus, architecto
                    optio asperiores mollitia pariatur error, quaerat voluptatibus minima eos quo nostrum, maxime
                    necessitatibus.</p>
            </div>
            <div class="team_member">
                <div class="member_img">
                    <img src="/img/toqs.png" alt="our_team">
                    <div class="social_media">
                        <div class="facebook item"><i class="fab fa-facebook-f"></i></div>
                        <div class="twitter item"><i class="fab fa-twitter"></i></div>
                        <div class="instagram item"><i class="fab fa-instagram"></i></div>
                    </div>
                </div>
                <h3>Christy Toquero</h3>
                <span>Accountant</span>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolores maiores temporibus, architecto
                    optio asperiores mollitia pariatur error, quaerat voluptatibus minima eos quo nostrum, maxime
                    necessitatibus.</p>
            </div>
            <div class="team_member">
                <div class="member_img">
                    <img src="/img/jeah.png" alt="our_team">
                    <div class="social_media">
                        <div class="facebook item"><i class="fab fa-facebook-f"></i></div>
                        <div class="twitter item"><i class="fab fa-twitter"></i></div>
                        <div class="instagram item"><i class="fab fa-instagram"></i></div>
                    </div>
                </div>
                <h3>Jeah Marie Ypil</h3>
                <span>Product Manager</span>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ratione perspiciatis, error deleniti
                    quaerat beatae doloribus incidunt excepturi. Fugit deleniti accusantium neque hic quidem
                    voluptatibus cumque.</p>
            </div>
            <div class="team_member">
                <div class="member_img">
                    <img src="/img/joy.png" alt="our_team">
                    <div class="social_media">
                        <div class="facebook item"><i class="fab fa-facebook-f"></i></div>
                        <div class="twitter item"><i class="fab fa-twitter"></i></div>
                        <div class="instagram item"><i class="fab fa-instagram"></i></div>
                    </div>
                </div>
                <h3>Joy Reambonanza</h3>
                <span>product analyst</span>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ratione perspiciatis, error deleniti
                    quaerat beatae doloribus incidunt excepturi. Fugit deleniti accusantium neque hic quidem
                    voluptatibus cumque.</p>
            </div>
        </div>
    </div>

    <br>

    <section class="footer_get_touch_outer">
        <div class="container">
            <div class="footer_get_touch_inner grid-70-30">
                <div class="colmun-70 get_form">
                    <div class="get_form_inner">
                        <div class="get_form_inner_text">
                            <h3>Get In Touch</h3>
                        </div>
                        <form method="post" action="<?php echo e(url('addFeedback')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <div class="grid-50-50">
                                <input type="text" name="name" placeholder="Name">
                                <input type="email" name="email" placeholder="Email">
                                <input type="subject" name="subject" placeholder="Subject">
                            </div>
                            <div class="grid-full">
                                <textarea placeholder="Message/Suggestions" name="message" cols="30" rows="10"></textarea>
                                <a href="/contacts"><input type="submit" value="Submit"></a>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="colmun-30 get_say_form">
                    <h5>Say Hi!</h5>
                    <ul class="get_say_info_sec">
                        <li>
                            <i class="fa fa-envelope"></i>
                            <a href="mailto:">toquero@gmail.com</a>
                        </li>
                        <li>
                            <i class="fa fa-whatsapp"></i>
                            <a href="tel:">+91 9602381997</a>
                        </li>
                        <li>
                            <i class="fa fa-skype"></i>
                            <a href="#">silent|killer</a>
                        </li>
                    </ul>
                    <ul class="get_say_social-icn">
                        <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                        <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                        <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <br>
    <!-- footer section starts  -->
    <section class="footer">

        <div class="box-container">
            <div class="box">
                <h3>quick links</h3>
                <a href="/landing"> <i class="fas fa-arrow-right"></i> home </a>
                <a href="/library"> <i class="fas fa-arrow-right"></i> Libarary </a>
                <a href="/contacts"> <i class="fas fa-arrow-right"></i> Contacts </a>
                <a href="/blogs"> <i class="fas fa-arrow-right"></i> Blogs </a>
            </div>

            <div class="box">
                <h3>contact info</h3>
                <a href="#"> <i class="fas fa-phone"></i> +123-456-7890 </a>
                <a href="#"> <i class="fas fa-phone"></i> +111-222-3333 </a>
                <a href="#"> <i class="fas fa-envelope"></i> VirEd@gmail.com </a>
                <a href="#"> <i class="fas fa-envelope"></i> VirEdPhilippines </a>
            </div>

            <div class="box">
                <h3>SNS</h3>
                <a href="https://facebook.com"> <i class="fab fa-facebook-f"></i> facebook </a>
                <a href="https://twitter.com"> <i class="fab fa-twitter"></i> twitter </a>
                <a href="https://instagram.com"> <i class="fab fa-instagram"></i> instagram </a>
                <a href="https://linkedin.com"> <i class="fab fa-linkedin"></i> linkedin </a>
            </div>
        </div>
        <div class="box">
            <footer style="color: white ;float: right;">
                <p>© Copyright 2022 Vired</p>
            </footer>
        </div>
    </section>
</body>

<script>
    let n = 0;

    function slide() {
        const images = document.getElementsByClassName("img");
        const button = document.getElementsByClassName("button");

        for (let i = 0; i < images.length; i++) {
            images[i].style = "display:none";
        }
        for (let i = 0; i < button.length; i++) {
            button[i].className = button[i].className.replace(" active", "");
        }

        n++;
        if (n > images.length) {
            n = 1;
        }

        images[n - 1].style = "display:block";
        button[n - 1].className += " active";

        setTimeout(slide, 3000);
    }

    slide();

    var span = document.querySelector(".typewriter span");
    var textArr = span.getAttribute("data-text").split(", ");
    var maxTextIndex = textArr.length;

    var sPerChar = 0.15;
    var sBetweenWord = 1.5;
    var textIndex = 0;

    typing(textIndex, textArr[textIndex]);

    function typing(textIndex, text) {
        var charIndex = 0;
        var maxCharIndex = text.length - 1;

        var typeInterval = setInterval(function() {
            span.innerHTML += text[charIndex];
            if (charIndex == maxCharIndex) {
                clearInterval(typeInterval);
                setTimeout(function() {
                    deleting(textIndex, text)
                }, sBetweenWord * 1000);

            } else {
                charIndex += 1;
            }
        }, sPerChar * 1000);
    }

    function deleting(textIndex, text) {
        var minCharIndex = 0;
        var charIndex = text.length - 1;

        var typeInterval = setInterval(function() {
            span.innerHTML = text.substr(0, charIndex);
            if (charIndex == minCharIndex) {
                clearInterval(typeInterval);
                textIndex + 1 == maxTextIndex ? textIndex = 0 : textIndex += 1;
                setTimeout(function() {
                    typing(textIndex, textArr[textIndex])
                }, sBetweenWord * 1000);
            } else {
                charIndex -= 1;
            }
        }, sPerChar * 1000);
    }
</script>

</html>
<?php /**PATH C:\Users\User\VirEd\resources\views/contacts.blade.php ENDPATH**/ ?>