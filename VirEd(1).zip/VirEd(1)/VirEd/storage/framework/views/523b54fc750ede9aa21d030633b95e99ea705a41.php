<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Index Page</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
  </head>
  <body>

    
    <div class="container">
    <br />
    <?php if(\Session::has('success')): ?>
      <div class="alert alert-success">
        <p><?php echo e(\Session::get('success')); ?></p>
      </div><br />
     <?php endif; ?>
    <table class="table table-striped">
    <thead>
      <tr>
    
        <th>Sex</th>
        <th>Firstname</th>
        <th>lastname</th>
        <th>bdate</th>
        <th>placeofbirth</th>
        <th>id</th>
        <th colspan="2">Action</th>
      </tr>
    </thead>
    <tbody>
      
      <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
      <tr>
        <td><?php echo e($car->id); ?></td>
        <td><?php echo e($car->carcompany); ?></td>
        <td><?php echo e($car->model); ?></td>
        <td><?php echo e($car->price); ?></td>
        <td><a href=<?php echo e('edit/'. $car['id']); ?> class="btn btn-warning">Edit</a></td>
        <td>
          <form action=<?php echo e('destroy'. $car['id']); ?> method="post">
            <?php echo csrf_field(); ?>
            <input name="_method" type="hidden" value="DELETE">
            <button class="btn btn-danger" type="submit">Delete</button>
          </form>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
  </div>
  </body>
</html><?php /**PATH C:\Users\User\laravelmongodb\resources\views/carindex.blade.php ENDPATH**/ ?>