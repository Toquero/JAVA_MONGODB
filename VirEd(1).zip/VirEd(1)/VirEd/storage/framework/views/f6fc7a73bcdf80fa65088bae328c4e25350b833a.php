<!DOCTYPE html>
<html lang="en">

<?php $__env->startSection('content'); ?>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('css/AdminDash.css')); ?>">
    <title>Admin Dashboard</title>
    <style>
        header nav {
            background: #3fafff;
            display: flex;
            align-items: center;
            border-bottom: var(--border);
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            text-shadow: #000000, 10px;
        }

        nav img {
            max-width: 10rem;
            max-height: 10rem;
            border-radius: 100%;
            /* margin:0.5rem 3rem 0.3rem 8rem; */
            margin: 2.5rem 2.5rem -3.6rem 8rem;
        }

        nav ul li {
            display: inline-block;


        }

        nav ul li a {
            color: rgb(0, 0, 0);
            padding: 0 1.9rem 0 2.3rem;
            font-size: 2.2rem;
            font-weight: bold;
            font-family: 'Acme', sans-serif;
            float: left;
            display: block;
            text-align: center;
            padding: 14px;
            text-decoration: none;
        }

        nav ul li:hover {
            font-size: 1.4rem;
            color: var(--main-color);
            border-bottom: .1rem solid var(--main-color);
            padding-bottom: .5rem;
        }

        header nav .search-form {
            background: #ffffff;
            width: 45rem;
            height: 4.4rem;
            display: flex;
            align-items: center;
            border-radius: 5px;
            padding: 0 0 0 1.2rem;
            margin: 0 0 0 6rem;

        }

        header nav .search-form input {
            font-size: 1.4rem;
            width: 100%;
            text-transform: none;
            color: var(--black);
            border: none;
            outline: none;

        }

        header nav .fa-search {
            color: var(--black);
            cursor: pointer;
            font-size: 2.5rem;
            margin: 0.2rem 0.5rem 0 0;
        }

        header nav .user_icon .fa-user {
            font-size: 3.5rem;
            margin: 0 0 0 2.3rem;
        }
    </style>
</head>

<body>
    <header>
        <nav>
            <a href="/landing"><img src="/img/logo.jpg" alt="logo"></a>
            <ul>
                <li><a href="<?php echo e(url('/adminHome')); ?>">Home</a></li>
                <li><a href="<?php echo e(url('/home')); ?>">User View</a></li>
                <li><a href="<?php echo e(url('/AdminDash')); ?>">Students</a></li>
                <li><a href="<?php echo e(url('/feedback')); ?>">Feedback</a></li>

            </ul>
    </header>

    <!-- this code is for the table -->
    <div class="invent">
        <div class="inventory detail">
            <div class="detail-header">
                <h1>Student Information</h1>
            </div>
            <div id="idcon">
                <table id="tab">
                    <tr>
                        <th name="name">Name</th>
                        <th name="email">Email</th>
                        <th name="subject">Subject</th>
                        <th name="message">Message</th>
                    </tr>
                    <?php $__currentLoopData = $feedback; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($feedback->name); ?></td>
                            <td><?php echo e($feedback->email); ?></td>
                            <td><?php echo e($feedback->subject); ?></td>
                            <td><?php echo e($feedback->message); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>
        </main>

        <!-- JavaScript Bundle with Popper -->
        <script src="https://kit.fontawesome.com/f2da3bba74.js" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous">
        </script>

</body>
<script src="<?php echo e(asset('js/landing.js')); ?>"></script>
<?php $__env->stopSection(); ?>
</html>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\VirEd\resources\views/feedback.blade.php ENDPATH**/ ?>