<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo e(asset('css/click.css')); ?>">
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Open+Sans:ital,wght@0,300;0,400;0,500;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&display=swap"
        rel="stylesheet">
    <script src="https://kit.fontawesome.com/a2b60a4aa3.js" crossorigin="anonymous"></script>
    <title>Click Me here Page</title>
</head>
<style>
    @import url('https://fonts.googleapis.com/css2?family=Acme&display=swap');

    * {
        padding: 0;
        margin: 0;
        font-family: 'Acme', sans-serif;
    }

    .content {
        max-width: 1250px;
        margin: auto;
        padding: 0 100px;
    }

    .navbar {
        position: fixed;
        width: 100%;
        z-index: 2;
        padding: 20px 0;
        transition: all 0.3s ease;
        background-image: url(/img/7.2.jpg);
        background-color: #f38031;

    }

    .navbar.sticky {
        background-color: #f38031;
        padding: 10px 0;
        box-shadow: 0px 3px 5px 0px rgba(0, 0, 0, 0.1);
    }

    .navbar .content {
        display: flex;
        align-items: center;
        justify-content: space-between;
    }


    .navbar .logo a {
        color: #fff;
        font-size: 20px;
        font-weight: 600;
        text-decoration: none;
    }

    .navbar .menu-list {
        display: inline-flex;
    }

    .menu-list li {
        list-style: none;
    }

    .menu-list li a {
        color: #fff;
        font-size: 15px;
        font-weight: 500;
        margin-left: 25px;
        text-decoration: none;
        transition: all 0.3s ease;
    }

    .menu-list li a:hover {
        color: #b074b8;
    }


    .icon {
        color: #fff;
        font-size: 20px;
        cursor: pointer;
        display: none;
    }

    .menu-list .cancel-btn {
        position: absolute;
        right: 30px;
        top: 20px;
    }



    @media (max-width: 1230px) {
        .content {
            padding: 0 60px;
        }

        .scroll-icon-container {
            margin: 0 auto
        }
    }

    @media (max-width: 1100px) {
        .content {
            padding: 0 60px;
        }

        .scroll-icon-container {
            margin: 0 auto
        }

        .search {
            margin: auto;

        }
    }

    @media (max-width: 900px) {
        .content {
            padding: 0 30px;
        }

        .scroll-icon-container {
            margin: 0 auto
        }
    }

    @media (max-width: 868px) {
        body.disabled {
            overflow: hidden;
        }

        .search {
            padding-top: 20px;
        }

        .scroll-icon-container {
            margin: 0 auto
        }

        .icon {
            display: block;
        }

        .icon.hide {
            display: none;
        }

        .navbar .content .menu-list {
            position: fixed;
            height: 100vh;
            width: 100%;
            max-width: 400px;
            left: -100%;
            top: 0px;
            display: block;
            padding: 40px 0;
            text-align: center;
            background:
                #64547c;
            transition: all 0.3s ease;
        }

        .navbar.show .menu-list {
            left: 0%;
        }

        .navbar .menu-list li {
            margin-top: 45px;
        }

        .navbar .menu-list li a {
            font-size: 23px;
            margin-left: -100%;
            transition: 0.6s cubic-bezier(0.68, -0.55, 0.265, 1.55);
        }

        .navbar.show .menu-list li a {
            margin-left: 0px;
        }
    }

    @media (max-width: 380px) {
        .navbar .logo a {
            font-size: 27px;
        }
    }






    @import url("https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400;1,600&display=swap");

    :root {
        --hero-gap: 60px;
    }

    * {
        box-sizing: border-box;
    }



    .cards h1 {
        font-size: calc(0.8rem + 8vmin);
        font-weight: 600;
        font-style: italic;
    }

    .cardsh2 {
        font-size: calc(0.8rem + 4vmin);
        font-weight: 600;
        font-style: italic;
        line-height: 1.2;
    }



    .caption {
        position: absolute;
        bottom: 1rem;
        right: 1rem;
        color: white;
        z-index: 2;
        font-size: 0.6rem;
    }

    .parallax-wrapper {
        height: 100vh;
        overflow-x: hidden;
        overflow-y: scroll;
        perspective: 10px;
    }

    .parallax-content {
        position: relative;
        width: 100%;
        height: calc(110vh - var(--hero-gap));
    }

    .hero {
        position: relative;
        display: flex;
        align-items: center;
        justify-content: center;
        overflow: hidden;
    }

    .hero img {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        -o-object-fit: cover;
        object-fit: cover;
        z-index: 1;
        transform: translateZ(-1px);
    }

    .hero .hero__title {
        color: white;
        z-index: 2;
        text-align: center;
        transform: translateZ(-2px) scale(1.2);
    }

    .hero .hero__title p {
        margin-top: 0.5rem;
        font-size: calc(0.6rem + 0.75vmin);
    }

    .hero .hero__title a {
        color: white;
    }

    .hero::after {
        content: "";
        position: absolute;
        top: 50%;
        left: 0;
        width: 100%;
        height: 100%;
        transform-origin: 0 100%;
        transform: translateZ(8px);
        pointer-events: none;
        background-image: linear-gradient(to bottom, rgba(0, 0, 0, 0) 0%, rgba(0, 0, 0, 0.013) 8%, rgba(0, 0, 0, 0.049) 14.8%, rgba(0, 0, 0, 0.104) 20.8%, rgba(0, 0, 0, 0.175) 26%, rgba(0, 0, 0, 0.259) 30.8%, rgba(0, 0, 0, 0.352) 35.3%, rgba(0, 0, 0, 0.45) 39.8%, rgba(0, 0, 0, 0.55) 44.5%, rgba(0, 0, 0, 0.648) 49.5%, rgba(0, 0, 0, 0.741) 55.2%, rgba(0, 0, 0, 0.825) 61.7%, rgba(0, 0, 0, 0.896) 69.2%, rgba(0, 0, 0, 0.951) 77.9%, rgba(0, 0, 0, 0.987) 88.1%, black 100%);
        z-index: 3;
    }

    .main {
        position: relative;
        margin: 0 auto;
        padding: var(--hero-gap) 2rem;
        max-width: 725px;
        background-color: white;

    }


    .main-content>*+* {
        margin-top: 2rem;
    }

    .scroll-icon-container {
        --size: 30px;
        display: flex;
        align-items: center;
        justify-content: center;
        position: absolute;
        overflow: hidden;
        top: calc(var(--size) * -1);
        left: 0;
        right: 0;
        margin: 0 auto;
        width: calc(var(--size) * 2);
        height: calc(var(--size) * 2);
        border-radius: 0.15rem;
        background-color: inherit;
        box-shadow: 0 6px 12px -3px rgba(0, 0, 0, 0.1);
        z-index: 4;

    }

    .scroll-icon-container .icon--down-arrow {
        width: var(--size);
        height: var(--size);
    }

    .search {
        display: table;
        padding-left: 100px;
    }

    .search input {
        background: none;
        border: none;
        outline: none;
        width: 28px;
        min-width: 0;
        padding: 0;
        z-index: 1;
        position: relative;
        line-height: 18px;
        margin: 5px 0;
        font-size: 14px;
        -webkit-appearance: none;
        font-family: 'Poppins';
        transition: all 0.6s ease;
        cursor: pointer;
        color: #fff;
    }

    .search input+div {
        position: relative;
        height: 28px;
        width: 100%;
        margin: -28px 0 0 0;
    }

    .search input+div svg {
        display: block;
        position: absolute;
        height: 28px;
        width: 160px;
        right: 0;
        top: 0;
        fill: none;
        stroke: #fff;
        stroke-width: 1.5px;
        stroke-dashoffset: 271.908;
        stroke-dasharray: 59 212.908;
        transition: all 0.6s ease;
    }

    .search input:not(:-moz-placeholder-shown) {
        width: 160px;
        padding: 0 4px;
        cursor: text;
    }

    .search input:not(:-ms-input-placeholder) {
        width: 160px;
        padding: 0 4px;
        cursor: text;
    }

    .search input:not(:placeholder-shown),
    .search input:focus {
        width: 160px;
        padding: 0 4px;
        cursor: text;
    }

    .search input:not(:-moz-placeholder-shown)+div svg {
        stroke-dasharray: 150 212.908;
        stroke-dashoffset: 300;
    }

    .search input:not(:-ms-input-placeholder)+div svg {
        stroke-dasharray: 150 212.908;
        stroke-dashoffset: 300;
    }

    .search input:not(:placeholder-shown)+div svg,
    .search input:focus+div svg {
        stroke-dasharray: 150 212.908;
        stroke-dashoffset: 300;
    }

    ::-moz-selection {
        background: rgba(255, 255, 255, 0.2);
    }

    ::selection {
        background: rgba(255, 255, 255, 0.2);
    }

    ::-moz-selection {
        background: rgba(255, 255, 255, 0.2);
    }

    html {
        box-sizing: border-box;
        -webkit-font-smoothing: antialiased;
    }

    * {
        box-sizing: inherit;
    }

    *:before,
    *:after {
        box-sizing: inherit;
    }


    body .dribbble {
        position: fixed;
        display: block;
        right: 24px;
        bottom: 24px;
    }

    body .dribbble img {
        display: block;
        width: 76px;
    }


    :root {
        --color: #3c3163;
        --transition-time: 0.5s;
    }

    * {
        box-sizing: border-box;
    }

    a {
        color: inherit;
    }

    .cards-wrapper {
        display: grid;
        justify-content: center;
        align-items: center;
        grid-template-columns: 1fr 1fr 1fr;
        grid-gap: 4rem;
        padding: 3rem;
        margin: 0 auto;
        width: max-content;
    }

    .cards {
        font-family: 'Poppins';
        --bg-filter-opacity: 0.5;
        background-image: linear-gradient(rgba(0, 0, 0, var(--bg-filter-opacity)), rgba(0, 0, 0, var(--bg-filter-opacity))), var(--bg-img);
        height: 20em;
        width: 15em;
        font-size: 1.5em;
        color: white;
        border-radius: 1em;
        padding: 1em;
        /*margin: 2em;*/
        display: flex;
        align-items: flex-end;
        background-size: cover;
        background-position: center;

        transition: all, var(--transition-time);
        position: relative;
        overflow: hidden;

        text-decoration: none;
    }

    .cards:hover {
        transform: rotate(0);
    }

    .cards h1 {
        margin: 0;
        font-size: 1.5em;
        line-height: 1.2em;
    }

    .cards p {
        font-size: 0.75em;
        font-family: 'Open Sans';
        margin-top: 0.5em;
        line-height: 2em;
    }

    .cards .tags {
        display: flex;
    }

    .cards .tags .tag {
        font-size: 0.75em;
        background: rgba(255, 255, 255, 0.5);
        border-radius: 0.3rem;
        padding: 0 0.5em;
        margin-right: 0.5em;
        line-height: 1.5em;
        transition: all, var(--transition-time);
    }

    .cards:hover .tags .tag {
        background: var(--color);
        color: white;
    }

    .cards .date {
        position: absolute;
        top: 0;
        right: 0;
        font-size: 0.75em;
        padding: 1em;
        line-height: 1em;
        opacity: .8;
    }

    .cards:before,
    .cards:after {
        content: '';
        transform: scale(0);
        transform-origin: top left;
        border-radius: 50%;
        position: absolute;
        left: -50%;
        top: -50%;
        z-index: -5;
        transition: all, var(--transition-time);
        transition-timing-function: ease-in-out;
    }


    .card-grid-space .num {
        font-size: 3em;
        margin-bottom: 1.2rem;
        margin-left: 1rem;
    }

    .info {
        font-size: 2em;
        display: flex;
        padding: 0em 2em;
        margin-top: 2rem;

        justify-content: center;
        max-width: 1250px;
        margin: 0 auto;
        padding: 0 20px;
        padding-top: 150px;
        padding-bottom: 40px;


    }

    .info img {
        height: 3em;
        margin-right: 0.5em;
    }

    .info h1 {
        font-size: 1em;
        font-weight: 600;
        z-index: 2;
        margin-top: -5%;
    }

    /*
 QUERIES */
    @media screen and (max-width: 1285px) {
        .cards-wrapper {
            grid-template-columns: 1fr 1fr;
        }

        .info {
            justify-content: center;
        }

    }

    @media screen and (max-width: 900px) {
        .cards-wrapper {
            grid-template-columns: 1fr;
        }

        .info {
            justify-content: center;
        }


        .card-grid-space .num {
            margin-left: 0;
            text-align: center;
        }
    }

    @media screen and (max-width: 500px) {
        .cards-wrapper {
            padding: 0.5rem 0.5rem;
        }

        .cards {
            max-width: calc(100vw - 4rem);
        }


    }

    @media screen and (max-width: 450px) {
        .info {
            display: block;
            text-align: center;
        }

        .info h1 {
            margin: 0;
        }
    }


    .wrapper {
        width: 400px;
        padding: 20px;
        margin: 20px auto;
        background-color: #ffffff;

        border-radius: 4px;
    }

    .hero__title h1 {
        font-size: 50px;
        font-weight: bold;
        margin-bottom: 20px;
    }

    .view {
        color: #5f4e79;
        padding: 40px;
        text-align: center;
        cursor: pointer;
    }

    .view a {
        text-decoration: none;
        font-size: 1.2rem;
    }

    .pager {
        margin: 0 0 3.75rem;
        font-size: 0;
        text-align: center;
    }

    .pager__item {
        display: inline-block;
        vertical-align: top;
        font-size: 1.125rem;
        font-weight: bold;
        margin: 0 2px;
    }

    .pager__item.active .pager__link {
        background-color: #5f4e79;
        border-color: #5f4e79;
        color: #fff;
        text-decoration: none;
    }

    .pager__item--prev svg,
    .pager__item--next svg {
        width: 8px;
        height: 12px;
    }

    .pager__item--next .pager__link svg {
        transform: rotate(180deg);
        transform-origin: center center;
    }

    .pager__link {
        position: relative;
        border-radius: 4px;
        display: block;
        text-align: center;
        width: 2.625rem;
        height: 2.625rem;
        line-height: 2.625rem;
        margin-left: -1px;
        color: #2f3640;
        text-decoration: none;
        transition: 0.3s;
    }

    .pager__link:hover,
    .pager__link:focus,
    .pager__link:active {
        background-color: #5f4e79;
        border-color: #5f4e79;
        color: #fff;
        text-decoration: none;
    }

    .pager__link:hover svg path,
    .pager__link:focus svg path,
    .pager__link:active svg path {
        fill: #fff;
    }

    .pager .pager__item.active+.pager__item .pager__link,
    .pager .pager__item:hover+.pager__item .pager__link {
        border-left-color: #ffb74d;
    }

    @media screen and (max-width: 576px) {
        .pager__item {
            position: absolute;
            top: -9999px;
            left: -9999px;
        }

        .pager__item.active,
        .pager__item:first-of-type,
        .pager__item:last-of-type,
        .pager__item:nth-of-type(2),
        .pager__item:nth-last-of-type(2) {
            position: initial;
            top: initial;
            left: initial;
        }

        .pager__item.active+li {
            position: initial;
            top: initial;
            left: initial;
        }
    }


    .subscribe {
        background: #f8f9fa;
        padding: 20px
    }

    .card {
        background: #f8f9fa;
        border-radius: 12px;

        height: 200px;
        overflow: hidden;
        padding: 20px;
        position: relative;
        width: 300px;
        margin: 0 auto
    }

    .title {
        font-size: 1.5em;
        height: 29px;
        margin-bottom: 0;
    }

    .text {
        color: #667;
        font-size: 1em;
        height: 38px;
        margin: 5px 0 0;
    }

    .line {
        left: 0;
        position: absolute;
        width: 340px;
    }

    .line path {
        fill: none;
        stroke: black;
        stroke-width: 2;
        stroke-dasharray: 300 1903;
    }

    .card.saving .line path {
        stroke-dashoffset: -472;
        stroke-dasharray: 153 1903;
        transition: stroke-dasharray 500ms, stroke-dashoffset 500ms;
    }

    .card.done .line path {
        stroke-dashoffset: -762;
        stroke-dasharray: 1095 1903;
        transition: stroke-dasharray 1500ms, stroke-dashoffset 1500ms;
    }

    .line2 {
        height: 52px;
        left: 150px;
        opacity: 0;
        position: absolute;
        stroke-dasharray: 6 48;
        stroke-dashoffset: -42;
        top: 140px;
        transform-origin: 50%;
        width: 50px;
    }

    .card.saving .line2 {
        animation: 4s 500ms Rotate forwards;
    }

    .card.done .line2 {
        animation: 500ms ScaleDown forwards;
    }

    .form {
        transform-origin: 0 50%;
        transition: transform 500ms, opacity 500ms;
    }

    .card.saving .form {
        transform: translateY(-16px) scale(.8);
    }

    .card.done .form {
        transform: translateY(-16px) scale(.8);
        opacity: 0;
    }

    .input {
        background: transparent;
        border: 0;
        box-sizing: border-box;
        font-size: 20px;
        height: 40px;
        margin-top: 20px;
        outline: none !important;
        position: relative;
        width: 300px;
    }

    @keyframes Rotate {
        0% {
            transform: rotate(0);
            opacity: 1;
        }

        25% {
            transform: rotate(360deg);
            opacity: 1;
        }

        50% {
            transform: rotate(720deg);
            opacity: 1;
        }

        75% {
            transform: rotate(1080deg);
            opacity: 1;
            stroke-dasharray: 6 48;
            stroke-dashoffset: -42;
        }

        100% {
            transform: rotate(1080deg);
            opacity: 1;
            stroke-dashoffset: 0;
            stroke-dasharray: 36 48;
        }
    }

    @keyframes ScaleDown {
        0% {
            transform: scale(1);
        }

        100% {
            transform: scale(0);
        }
    }

    footer {
        display: grid;
        justify-content: center;
        align-items: center;
        padding: 3rem;
        margin: 0 auto;
        width: 100%;
        background: #f38031;
        color: white;

    }

    footer h1 {
        font-size: 20px;
    }

    /* Icons */

    .social a {
        color: #fff;

        border-radius: 4px;
        text-align: center;
        text-decoration: none;
        font-family: fontawesome;
        position: relative;
        display: inline-block;
        width: 40px;
        height: 28px;
        padding-top: 6px;
        margin: 0 10px;
        -o-transition: all .5s;
        -webkit-transition: all .5s;
        -moz-transition: all .5s;
        transition: all .5s;
        -webkit-font-smoothing: antialiased;
    }

    .social a:hover {
        background: #B0A7BD;
    }

    /* pop-up text */

    .social a span {
        color: #666;
        position: absolute;
        font-family: sans-serif;
        bottom: 0;
        left: -25px;
        right: -25px;
        padding: 2px 7px;
        z-index: -1;
        font-size: 14px;
        border-radius: 2px;
        background: #fff;
        visibility: hidden;
        opacity: 0;
        -o-transition: all .5s cubic-bezier(0.68, -0.55, 0.265, 1.55);
        -webkit-transition: all .5s cubic-bezier(0.68, -0.55, 0.265, 1.55);
        -moz-transition: all .5s cubic-bezier(0.68, -0.55, 0.265, 1.55);
        transition: all .5s cubic-bezier(0.68, -0.55, 0.265, 1.55);
    }

    .social a:nth-of-type(1):before {
        content: '\f09a';
    }

    .social a:nth-of-type(2):before {
        content: '\f099';
    }

    .social a:nth-of-type(3):before {
        content: '\f0d5';
    }

    .social a:nth-of-type(4):before {
        content: '\f113';
    }

    .social a:nth-of-type(5):before {
        content: '\f17d';
    }

    .social a:nth-of-type(6):before {
        content: '\f1cb';
    }

    .copyright {
        margin: 0 auto;
        margin-top: 20px;
    }

    @media (max-width: 1230px) {
        .copyright {
            margin: 0 auto;
            margin-top: 20px;
            text-align: center;
        }

        .social {
            margin: 0 auto;
        }
    }

    @media (max-width: 1100px) {
        .copyright {
            margin: 0 auto;
            margin-top: 20px;
            text-align: center;
        }

        .social {
            margin: 0 auto;
        }
    }

    @media (max-width: 900px) {
        .copyright {
            margin: 0 auto;
            margin-top: 20px;
            text-align: center;
        }

        .social {
            margin: 0 auto;
        }
    }

    @media (max-width: 868px) {
        .copyright {
            margin: 0 auto;
            margin-top: 20px;
            text-align: center;
        }

        .social {
            margin: 0 auto;
        }
    }

    @media (max-width: 380px) {
        .copyright {
            margin: 0 auto;
            margin-top: 20px;
            text-align: center;
        }

        .social {
            margin: 0 auto;
        }
    }


    * {
        box-sizing: border-box;
    }

    .blog-card {
        display: flex;
        flex-direction: column;
        margin: 1rem auto;
        box-shadow: 0 3px 7px -1px rgba(0, 0, 0, 0.1);
        margin-bottom: 1.6%;
        background: #fff;
        line-height: 2;
        font-family: sans-serif;
        border-radius: 5px;
        overflow: hidden;
        z-index: 0;

    }

    .blog-card a {
        color: inherit;
        text-decoration: none;
    }

    .blog-card a:hover {
        color: #b074b8;
    }

    .blog-card:hover .photo {
        transform: scale(1.3) rotate(3deg);
    }

    .blog-card .meta {
        position: relative;
        z-index: 0;
        height: 200px;
    }

    .blog-card .photo {
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
        background-size: cover;
        background-position: center;
        transition: transform 0.2s;
    }

    .blog-card .details,
    .blog-card .details ul {
        margin: auto;
        padding: 0;
        list-style: none;
    }

    .blog-card .details {
        position: absolute;
        top: 0;
        bottom: 0;
        left: -100%;
        margin: auto;
        transition: left 0.2s;
        background: rgba(0, 0, 0, 0.6);
        color: #fff;
        padding: 10px;
        width: 100%;
        font-size: 0.9rem;
    }

    .blog-card .details ul li {
        display: inline-block;
    }

    .blog-card .details .author:before {
        font-family: FontAwesome;
        margin-right: 10px;
        content: "";
    }

    .blog-card .details .date:before {
        font-family: FontAwesome;
        margin-right: 10px;
        content: "";
    }

    .blog-card .details .tags ul:before {
        font-family: FontAwesome;
        content: "";
        margin-right: 10px;
    }

    .blog-card .details .tags li {
        margin-right: 2px;
    }

    .blog-card .details .tags li:first-child {
        margin-left: -4px;
    }

    .blog-card .description {
        padding: 1rem;
        background: #fff;
        position: relative;
        z-index: 1;
    }

    .blog-card .description h1,
    .blog-card .description h2 {
        font-family: Poppins, sans-serif;
    }

    .blog-card .description h1 {
        line-height: 1;
        margin: 0;
        font-size: 1.7rem;
    }

    .blog-card .description h2 {
        font-size: 1rem;
        font-weight: 300;
        text-transform: uppercase;
        color: #a2a2a2;
        margin-top: 5px;
    }

    .blog-card .description .read-more {
        text-align: right;
    }

    .blog-card .description .read-more a {
        color: #5f4e79;
        display: inline-block;
        position: relative;
    }

    .blog-card .description .read-more a:after {
        content: "";
        font-family: FontAwesome;
        margin-left: -10px;
        opacity: 0;
        vertical-align: middle;
        transition: margin 0.3s, opacity 0.3s;
    }

    .blog-card .description .read-more a:hover:after {
        margin-left: 5px;
        opacity: 1;
    }

    .blog-card p {
        position: relative;
        margin: 1rem 0 0;
    }

    .blog-card p:first-of-type {
        margin-top: 1.25rem;
    }

    .blog-card p:first-of-type:before {
        content: "";
        position: absolute;
        height: 5px;
        background: #5f4e79;
        width: 35px;
        top: -0.75rem;
        border-radius: 3px;
    }

    .blog-card:hover .details {
        left: 0%;
    }

    @media (min-width: 640px) {
        .blog-card {
            flex-direction: row;
            max-width: 700px;
        }

        .blog-card .meta {
            flex-basis: 40%;
            height: auto;
        }

        .blog-card .description {
            flex-basis: 60%;
        }

        .blog-card .description:before {
            transform: skewX(-3deg);
            content: "";
            background: #fff;
            width: 30px;
            position: absolute;
            left: -10px;
            top: 0;
            bottom: 0;
            z-index: -1;
        }

        .blog-card.alt {
            flex-direction: row-reverse;
        }

        .blog-card.alt .description:before {
            left: inherit;
            right: -10px;
            transform: skew(3deg);
        }

        .blog-card.alt .details {
            padding-left: 25px;
        }
    }

    .me img {
        width: 100px;
        height: auto;
        border-radius: 200px;
    }

    .fir-clickcircle {
        height: 80px;
        width: 80px;
        border-radius: 100px;
        cursor: pointer;
    }

    .fir-image-figure {
        margin: 0;
        display: flex;
        align-items: center;
        margin-bottom: 40px;
        position: relative;
        text-decoration: none;
    }

    html.wf-active .fir-image-figure .fig-author-figure-title {
        font-family: var(--fir-font-header);
        font-size: 16px;
    }

    .fir-image-figure .fig-author-figure-title {
        color: var(--fir-color-grey);
        font-family: "HelveticaNeue-Light", "Helvetica Neue Light", "Helvetica Neue", Helvetica, Arial, "Lucida Grande", sans-serif;
        font-weight: 400;
        font-size: 15px;
        margin-top: 2px;
    }

    .fir-imageover {
        position: relative;
        display: flex;
    }


    @keyframes fadeInFadeOut {
        0% {
            opacity: 1;
        }

        50% {
            opacity: 0;
        }

        100% {
            opacity: 1;
        }
    }

    figcaption {
        color: rgba(0, 0, 0, 0.40);

    }

    .intro h1 {
        font-weight: 500;
        padding-top: 50px;
    }

    .intro {
        position: relative;
        width: 60%;
        font-size: 18px;
        line-height: 1.5;
        margin-left: 150px;
        margin: 0 auto
    }

    .about {
        display: grid;

        justify-content: center;
        align-items: center;
        grid-template-columns: 1fr 2.8fr;
        margin: 0 auto;
        max-width: 1326px;
    }

    .me {
        position: relative;
        width: 100%;
        margin-top: -550px;
        margin-left: 200px;
    }

    .intro p {
        padding-top: 20px;
        font-family: 'Poppins';
        font-weight: 400;
        color: #313b44;
    }

    @media(max-width:1302px) {
        .me {
            position: relative;
            width: 100%;
            margin-top: -600px;
            margin-left: 200px;
        }

    }

    @media(max-width:1206px) {
        .me {
            position: relative;
            width: 100%;
            margin-top: -620px;

        }

    }


    @media(max-width:868px) {
        .about {
            display: inline-block;
            padding-top: 700px;
            margin: 0 auto;
            padding: 0 auto;
        }

        .me {
            margin-left: 150px;

        }

    }

    @media(max-width:364px) {
        .about {
            margin-left: -100px;
        }

        .intro h1 {
            font-size: 25px;
        }

        .intro p {
            font-size: 15px;
        }

    }

    @media(min-width:900px) {
        .about {
            margin-left: -20px;

        }

    }


    .forms {
        width: 340px;
        height: 440px;

        border-radius: 8px;
        box-shadow: 0px 5px 5px -1px rgb(0 0 0 / 20%);
        margin: 0 auto;
        padding: 20px 30px;
        max-width: calc(100vw - 40px);
        box-sizing: border-box;
        font-family: 'Montserrat', sans-serif;
        position: relative;
        margin-bottom: 180px;
        margin-top: 50px;
    }


    .forms h2 {
        margin: 10px 0;
        padding-bottom: 10px;
        width: 180px;
        color: #78788c;
        border-bottom: 3px solid #78788c
    }

    .forms p input {
        width: 100%;
        padding: 10px;
        box-sizing: border-box;
        background: none;
        outline: none;
        resize: none;
        border: 0;
        font-family: 'Montserrat', sans-serif;
        transition: all .3s;
        border-bottom: 2px solid #bebed2
    }

    .forms input:focus {
        border-bottom: 2px solid #78788c
    }

    .forms p:before {
        content: attr(type);
        display: block;
        margin: 28px 0 0;
        font-size: 14px;
        color: #5a5a5a
    }

    .forms button {
        float: right;
        padding: 8px 12px;
        margin: 8px 0 0;
        font-family: 'Montserrat', sans-serif;
        border: 2px solid #78788c;
        background: 0;
        color: #5a5a6e;
        cursor: pointer;
        transition: all .3s
    }

    .forms button:hover {
        background: #78788c;
        color: #fff
    }

    .contact {
        content: 'Hi';
        position: absolute;
        bottom: -30px;
        right: -20px;
        background: #5f4e79;
        color: #fff;
        width: 320px;
        padding: 16px 4px 16px 0;
        border-radius: 6px;
        font-size: 13px;
        box-shadow: 10px 10px 40px -14px
    }

    .contact span {
        margin: 0 5px 0 15px;
    }

    .btn-group .btn-primary {

        background-color: #f38031;
        text-decoration: none;
        padding: 1.5%;
        border: solid 3px #000000;


    }

    nav img {
        max-width: 8rem;
        max-height: 8rem;
        border-radius: 100%;
        /* margin: 0.5rem 3rem 0.3rem 8rem; */
        margin: 2rem 2rem -3rem 1rem;
    }

    img,
    svg {
        vertical-align: middle;
    }
</style>

<body>
    <nav class="navbar sticky">
        <div class="content">
            <div class="logo">
                <a href="/landing"><img src="/img/logo.jpg" alt="logo"></a>
            </div>
            <ul class="menu-list">
                <div class="icon cancel-btn">
                    <i class="fas fa-times"></i>
                </div>
                <li><a href="/landing">HOME</a></li>
                <li><a href="/library">LIBRARY</a></li>
                <li><a href="/quizzes">QUIZZES</a></li>
                <li><a href="/contacts">CONTACTS</a></li>
                <li><a class="nav-link active text-danger" href="/blogs">BLOGS</a></li>

                <div class="search">
                    <input type="text" placeholder=" ">
                    <div>
                        <svg>
                            <use xlink:href="#path">
                        </svg>
                    </div>
                </div>

                <svg xmlns="http://www.w3.org/2000/svg" style="display: none;">
                    <symbol xmlns="http://www.w3.org/2000/svg" viewBox="0 0 160 28" id="path">
                        <path
                            d="M32.9418651,-20.6880772 C37.9418651,-20.6880772 40.9418651,-16.6880772 40.9418651,-12.6880772 C40.9418651,-8.68807717 37.9418651,-4.68807717 32.9418651,-4.68807717 C27.9418651,-4.68807717 24.9418651,-8.68807717 24.9418651,-12.6880772 C24.9418651,-16.6880772 27.9418651,-20.6880772 32.9418651,-20.6880772 L32.9418651,-29.870624 C32.9418651,-30.3676803 33.3448089,-30.770624 33.8418651,-30.770624 C34.08056,-30.770624 34.3094785,-30.6758029 34.4782612,-30.5070201 L141.371843,76.386562"
                            transform="translate(83.156854, 22.171573) rotate(-225.000000) translate(-83.156854, -22.171573)">
                        </path>
                    </symbol>
                </svg>


                <a class="dribbble" href="https://dribbble.com/shots/5547403-Search-input-animation"
                    target="_blank"><img
                        src="https://dribbble.com/assets/logo-small-2x-9fe74d2ad7b25fba0f50168523c15fda4c35534f9ea0b1011179275383035439.png"
                        alt=""></a>

            </ul>
            <div class="icon menu-btn">
                <i class="fas fa-bars"></i>
            </div>
        </div>
    </nav>

    <div class="hero parallax-content"><img src="/img/7.2.jpg" alt="Photo of city during a sunset by Sterling Davis" />
        <div class="hero__title">
            <h1> VirEd Online Learning</h1>
            <p>Come and be part of our growing community</p><br><br>




            <script>
                const body = document.querySelector("body");
                const navbar = document.querySelector(".navbar");
                const menuBtn = document.querySelector(".menu-btn");
                const cancelBtn = document.querySelector(".cancel-btn");
                menuBtn.onclick = () => {
                    navbar.classList.add("show");
                    menuBtn.classList.add("hide");
                    body.classList.add("disabled");
                }
                cancelBtn.onclick = () => {
                    body.classList.remove("disabled");
                    navbar.classList.remove("show");
                    menuBtn.classList.remove("hide");
                }
                window.onscroll = () => {
                    this.scrollY > 20 ? navbar.classList.add("sticky") : navbar.classList.remove("sticky");
                }
            </script>

            <div class="btn-group">
                <a href="/contacts" class="btn btn-primary">Contact Me</a>
                <a href="/library" class="btn btn-primary">Click me to Learn</a>
            </div>

        </div>
    </div>

    <div class="info">
        <h1>Latest Blog Posts</h1>
    </div>

    <div class="blog-card">
        <div class="meta">
            <div class="photo" style="background-image: url(/img/22.png)">
            </div>
            <ul class="details">

                <li class="date">14 Oct 2022</li>
                <li class="tags">
                    <ul>
                        <li><a href="#">Online Learning</a></li>

                    </ul>
                </li>
            </ul>
        </div>
        <div class="description">
            <h1>Short Stories</h1>

            <p> Promote imagination, creativity and develop children's ability to communicate their thoughts and
                feelings, playing an important role in the development of children's communicative skills. Stories are
                also a great tool to develop empathy.</p>
            <p class="read-more">
                <a href="/stories">Read More</a>
            </p>
        </div>
    </div>
    <div class="blog-card alt">
        <div class="meta">
            <div class="photo" style="background-image: url(/img/11.png)">
            </div>
            <ul class="details">

                <li class="date">29 Jan 2022</li>
                <li class="tags">
                    <ul>
                        <li><a href="#">Online Learning</a></li>

                    </ul>
                </li>
            </ul>
        </div>
        <div class="description">
            <h1>English Vocabulary</h1>

            <p>Developing knowledge and skills in multiple aspects of language and literacy. This includes helping with
                decoding (phonemic awareness and phonics), comprehension, and also fluency.</p>
            <p class="read-more">
                <a href="/english">Read More</a>
            </p>
        </div>
    </div>

    <div class="blog-card">
        <div class="meta">
            <div class="photo" style="background-image: url(/img/33.png)"></div>
            <ul class="details">

                <li class="date">22 Jan 2022</li>
                <li class="tags">
                    <ul>
                        <li><a href="#">Online Learning</a></li>

                    </ul>
                </li>
            </ul>
        </div>
        <div class="description">
            <h1>Math Logics</h1>

            <p> To sharpen the logical and analytical skills of a student as these are necessary for the understanding
                and learning of mathematical proofs.</p>
            <p class="read-more">
                <a href="/math">Read More</a>
            </p>
        </div>
    </div>
    <div class="blog-card alt">
        <div class="meta">
            <div class="photo" style="background-image: url(/img/44.png)">
            </div>
            <ul class="details">

                <li class="date">15 Jan 2022</li>
                <li class="tags">
                    <ul>
                        <li><a href="#">Online Learning</a></li>

                    </ul>
                </li>
            </ul>
        </div>
        <div class="description">
            <h1>World of Science</h1>

            <p>Generates solutions for everyday life and helps us to answer the great mysteries of the universe. In
                other words, science is one of the most important channels of knowledge.</p>
            <p class="read-more">
                <a href="/science">Read More</a>
            </p>
        </div>
    </div>

    <div class="blog-card">
        <div class="meta">
            <div class="photo" style="background-image: url(/img/33.png)"></div>
            <ul class="details">

                <li class="date">22 Jan 2022</li>
                <li class="tags">
                    <ul>
                        <li><a href="#">Online Learning</a></li>

                    </ul>
                </li>
            </ul>
        </div>
        <div class="description">
            <h1>FIlipino Tales</h1>

            <p> To have better understanding on our ancestors' mindsets through these myths and acquaint ourselves with their way of
                life — and these will enrich our self-understanding as Filipinos.</p>
            <p class="read-more">
                <a href="/math">Read More</a>
            </p>
        </div>
    </div>
    <footer class="footer">
        <div class="social">
            <a href="#"><span>Facebook</span></a>
            <a href="#"><span>Twitter</span></a>
            <a href="#"><span>Google+</span></a>
            <a href="#"><span>Github</span></a>
            <a href="#"><span>Dribbble</span></a>
            <a href="#"><span>CodePen</span></a>
        </div>

        <div class="copyright">
            <p>COPYRIGHT ©2022 ALL RIGHTS RESERVED</p>
        </div>
    </footer>

</body>

</html>
<?php /**PATH C:\Users\Student.Admin\VirEd(1)\VirEd\resources\views/blogs.blade.php ENDPATH**/ ?>