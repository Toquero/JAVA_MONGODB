<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Laravel MongoDB CRUD Tutorial With Example</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">  
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>  
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
  </head>
  <body>
    <div class="container">
      <h2>Edit A Form</h2><br/>
      <div class="container">
    </div>
      <form action="/edit" method="POST">
        <?php echo csrf_field(); ?>
        <div class="row">
          <div class="col-md-4"></div>
          <div class="form-group col-md-4">
            <input type="hidden" name="id" value="<?php echo e($birth['id']); ?>"> <br>
            <input type="text" name="sex" readonly value="<?php echo e($birth['sex']); ?>"> <br>
            <input type="text" name="fname" readonly value="<?php echo e($birth['fname']); ?>"><br>
            <input type="text" name="mname" readonly value="<?php echo e($birth['mname']); ?>"><br>
            <input type="text" name="lname" readonly value="<?php echo e($birth['lname']); ?>"><br>
            <input type="text" name="birthdate" readonly value="<?php echo e($birth['birthdate']); ?>"><br>
            <input type="text" name="birthplace" readonly value="<?php echo e($birth['birthplace']); ?>"><br>
            <input type="text" name="idtype" readonly value="<?php echo e($birth['idtype']); ?>"><br>
            <input type="text" name="ffname" readonly value="<?php echo e($birth['ffname']); ?>"><br>
            <input type="text" name="fmname" readonly value="<?php echo e($birth['fmname']); ?>"><br>
            <input type="text" name="flname" readonly value="<?php echo e($birth['flname']); ?>"><br>
            <input type="text" name="mfname" readonly value="<?php echo e($birth['mfname']); ?>"><br>
            <input type="text" name="mmname" readonly value="<?php echo e($birth['mmname']); ?>"><br>
            <input type="text" name="mlname" readonly value="<?php echo e($birth['mlname']); ?>"><br>
            <input type="text" name="lateReg" readonly value="<?php echo e($birth['lateReg']); ?>"><br>
            <input type="text" name="purpose" readonly value="<?php echo e($birth['purpose']); ?>"><br>
            <input type="text" name="status" value="<?php echo e($birth['status']); ?>"><br>
            <button type="submit">Update</button>
          </div>
        </div>
      </form>
   </div>
  </body>
</html><?php /**PATH C:\Users\User\laravelmongodb\resources\views/birthedit.blade.php ENDPATH**/ ?>