<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Index Page</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>

<body>


    <div class="container">
        <br />
        <?php if(\Session::has('success')): ?>
            <div class="alert alert-success">
                <p><?php echo e(\Session::get('success')); ?></p>
            </div><br />
        <?php endif; ?>
        <table class="table table-striped">
            <thead>
                <h1>Birth Certification Requests</h1>
                <tr>
                    <th>Sex</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Middle Name</th>
                    <th>Birthdate</th>
                    <th>Place of Birth</th>
                    <th>ID Presented</th>
                    <th>Father's First Name</th>
                    <th>Father's Middle Name</th>
                    <th>Father's Last Name</th>
                    <th>Mother's First Name</th>
                    <th>Mother's Middle Name</th>
                    <th>Mother's Last Name</th>
                    <th>Late Registration?</th>
                    <th>Purpose</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>

                
                        </td>

                        
                    </tr>
                
            </tbody>
        </table>


    </div>
</body>

</html>
<?php /**PATH C:\Users\User\Laravel Projects\laravelmongodb\resources\views/birthindex.blade.php ENDPATH**/ ?>