<?php

namespace App\Http\Controllers;

use App\Car;
use Illuminate\Http\Request;

class PostController extends Controller
{


   
}
