<?php

namespace App\Http\Controllers;

use App\Models\Feedback;

use Illuminate\Http\Request;


class FeedbackRecordController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */


    public function showFeedback()
    {
        $feedback = Feedback::all();
        return view('feedback', compact('feedback')); //databasename
    }
}
