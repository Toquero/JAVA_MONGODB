<?php

namespace App\Http\Controllers;

use Illuminate\Routing\Controller as Controller;
use App\Models\Feedback;
use Illuminate\Http\Request;

class FeedbackController extends Controller
{
    
    public function create()
    {
        return view('contacts');
    }

    public function store(Request $request)
    {
        $feedbackData = new Feedback();
        $feedbackData->name = $request->get('name');
        $feedbackData->email = $request->get('email');
        $feedbackData->message = $request->get('message');
        $feedbackData->save();
        return redirect('feedbackData'); //ig ka save sa db,, muredirect sa birthDetails nga value nga gidefine sa route nga 'index' ang adtuan
    }

    public function index()
    {
        return view('contacts'); //mao ni ang index nga ireturn
    }

}
