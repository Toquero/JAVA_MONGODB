<?php

namespace App\Http\Controllers;

use Illuminate\Routing\Controller as Controller;
use Illuminate\Http\Request;
use App\Models\Student;


class StudentController extends Controller
{
    public function create()
    {
        return view('UserDetails');
    }

    public function store(Request $request)
    {
        $status = 'Active';
        $userData = new Student();
        $userData->gender = $request->get('gender');
        $userData->name = $request->get('name');
        $userData->age = $request->get('age');
        $userData->FavoriteSubject = $request->get('FavoriteSubject');
        $userData->grade_level = $request->get('grade_level');
        $userData->school = $request->get('school');
        $userData->email = $request->get('email');
        $userData->status = ($status);
        $userData->save();
        return redirect('home'); //ig ka save sa db,, muredirect sa birthDetails nga value nga gidefine sa route nga 'index' ang adtuan
    }

    public function index()
    {
        return view('landing'); //mao ni ang index nga ireturn
    }
}
