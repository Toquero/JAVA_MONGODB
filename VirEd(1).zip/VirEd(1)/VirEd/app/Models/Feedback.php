<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Jenssegers\Mongodb\Eloquent\Model as Eloquent;

class Feedback extends Eloquent
{
    protected $connection = 'mongodb';
    protected $collection = 'feedback'; //collection sa database

    protected $fillable = [
        'name',
        'email',
        'message'
    ];
}