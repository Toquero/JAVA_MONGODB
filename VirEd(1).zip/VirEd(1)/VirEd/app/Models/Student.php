<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Jenssegers\Mongodb\Eloquent\Model as Eloquent;

class Student extends Eloquent
{
    protected $connection = 'mongodb';
    protected $collection = 'students'; //collection sa database

    protected $fillable = [
        'gender',
        'name',
        'age',
        'FavoriteSubject',
        'school',
        'grade_level',
        'email'
    ];
}