<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\UserDetailsController;
use App\Http\Controllers\StudentRecordController;
use App\Http\Controllers\FeedbackController;
use App\Http\Controllers\FeedbackRecordController;






Route::get('/', function () {
    return view('/UserDetails');
}); 


Route::get('/UserDetails', function(){
    return view('UserDetails');
}); 

Route::get('/AdminDash', function(){
    return view('AdminDash');
}); 

Route::get('/feedback', function(){
    return view('feedback');
}); 

Route::get('/contacts', function(){
    return view('contacts');
});

Auth::routes();

Route::get('addUser', [StudentController::class, 'create']);
Route::post('addUser', [StudentController::class, 'store']); //makita sa controller ang method

Route::get('/details', [UserDetailsController::class, 'index']); 
Route::get('/home   ', [StudentController::class, 'index']); 

Route::get('/adminHome', [HomeController::class, 'index']); 

Route::get('/AdminDash', [StudentRecordController::class, 'index']); 


//feedback
Route::get('addFeedback', [FeedbackController::class, 'create']);
Route::post('addFeedback', [FeedbackController::class, 'store']); //makita sa controller ang method

Route::get('/feedbackData', [FeedbackController::class, 'index']); 

Route::get('/feedback', [FeedbackRecordController::class, 'showFeedback']); 

Route::get('/library', function () {
    return view('library');
});

Route::get('/english', function () {
    return view('english');
});

Route::get('/englishExtend', function () {
    return view('englishExtend');
});

Route::get('/math', function () {
    return view('math');
});

Route::get('/science', function () {
    return view('science');
});

Route::get('/stories', function () {
    return view('stories');
});

Route::get('/filipino', function () {
    return view('filipino');
});

Route::get('/readmore', function () {
    return view('readmore');
});

Route::get('/quizzes', function () {
    return view('quizzes');
});

Route::get('/blogs', function () {
    return view('blogs');
});

Route::get('/load', function () {
    return view('load');
});

Route::get('/click', function () {
    return view('click');
});
Route::get('/contacts', function () {
    return view('contacts');
});
Route::get('/landing', function () {
    return view('landing');
});




