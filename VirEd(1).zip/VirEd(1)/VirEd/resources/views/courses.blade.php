<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Courses Page</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            -webkit-user-select: none;
        }

        :root {
            --blue: #2cd4f3;
            --orange: #f38031;
        }

        body {
            min-height: 100vh;
            min-height: -webkit-fill-available;
        }

        html {
            height: -webkit-fill-available;
        }

        main {
            display: flex;
            flex-wrap: nowrap;
            height: 100vh;
            max-height: 100vh;
            overflow-x: auto;
            overflow-y: hidden;
            background: var(--blue);
        }

        .side {
            background-color: var(--orange);
        }

        .bi {
            vertical-align: -.125em;
            pointer-events: none;
            fill: currentColor;
        }

        /* Table */

        .invent {
            display: grid;
            grid-template-columns: 2fr 1fr;
            grid-gap: 1rem;
            width: 100%;
            padding: 20px;
            margin-top: 50px;
            margin-bottom: 30px;
            height: 20vh;
        }

        .inventory {
            margin-top: -15px;
            background: white;
            padding: 10px;
            border-radius: 10px;
            box-shadow: grey;
        }

        .detail-header {
            display: grid;
            grid-auto-flow: column;
            justify-content: space-between;
            align-items: center;
        }

        .detail-header {
            font-size: 20px;
            color: black;
        }

        .detail #idcon {
            overflow-y: scroll;
            margin-top: 10px;
            padding-top: 0;
            height: 70vh;
        }

        #idcon::-webkit-scrollbar-track {
            background: none;
        }

        #idcon::-webkit-scrollbar {
            width: 10px;
            background-color: none;
        }

        #idcon::-webkit-scrollbar-thumb {
            background-color: none;
        }

        .detail table {
            width: 100%;
            border-collapse: collapse;
        }

        .detail table th {
            background-color: var(--orange);
            font-size: 16px;
            padding: 0.8rem 0.2rem;
            position: sticky;
            top: 0;
        }

        .detail table th:hover {
            border: none;
        }

        .detail table tr {
            font-size: 12px;
            border-bottom: 1px solid var(--orange);
        }

        .detail table tr:hover {
            background-color: var(--blue);
            border-bottom: 2px solid var(--blue);
        }

        .detail table tr td:last-child {
            text-align: center;
            cursor: pointer;
            color: #333333;
        }

        .detail table tr td:last-child:hover {
            color: white;
        }

        .detail table tr th:last-child {
            text-align: center;
        }

        .detail table td {
            padding: 0.4rem 0.2rem;
            font-size: 13px;
            text-align: center;
        }

        .detail table th {
            text-align: center;
            min-width: 100px;
            padding-left: 10px;
        }

        .detail table th {
            color: #FFFBE9;
        }


        .detail table tr td:nth-child(2),
        .detail table tr td:nth-child(3) {
            min-width: 100px;
        }

        .detail table .trash i {
            font-size: 12px;
        }

        .Add {
            background: white;
            margin-top: -1rem;
            padding: 20px;
            border-radius: 10px;
            box-shadow: var(--box-shadow);
        }

        .Add h1 {
            font-size: 25px;
            color: black;
            padding: 20px;
            text-align: center;
        }

        .Add input {
            background: transparent;
            border-bottom: 2px solid var(--orange);
            outline: none;
            width: 100%;
            border: none;
            margin-bottom: 0.5rem;
        }

        .Add input:focus {
            border: none;
            background: transparent;
            border-bottom: 2px solid var(--orange);
        }

        .Add [type="text"] {
            border: none;
            border-bottom: 2px solid var(--orange);
            width: 100%;
            padding: 10px;
        }

        .Add [type="date"] {
            border: none;
            border-bottom: 2px solid var(--orange);
            width: 100%;
            padding: 10px;
            margin-bottom: 1.3rem;
        }

        .Add select {
            background: transparent;
            border: none;
            outline: none;
            border-bottom: 2px solid var(--orange);
            width: 100%;
            padding: 1rem 1rem;
            font-size: 1.6rem;
            margin-bottom: 0.5rem;
            transition: .4s;
            border-radius: 4px;
            font-size: 13px;
        }


        .Add select option {
            padding: 20px;
            background: var(--orange);
            font-size: 16px;
        }

        .Add form button {
            margin-top: 20px;
            background-color: var(--orange);
            color: white;
            border: 1px solid var(--orange);
            padding: 5px 5rem;
            font-size: 18px;

        }

        .Add form button:hover {
            background: var(--blue);
            border-radius: 10px;
            color: black;
            letter-spacing: 2px;
            border: var(--blue);
        }
    </style>

</head>

<body>
    <main>
        <div class="d-flex flex-column flex-shrink-0  text-dark p-2 side" style="width: 250px; ">
            <hr>
            <a href="/AdminDash" class="d-flex align-items-center mb-3 px-2 mb-md-0 me-md-auto text-white text-decoration-none">
                <img src="/img/finalLogo.jpg" alt="" class="rounded-circle " width="50" height="50">
                <span class="fs-4 px-3">Administrator</span>
            </a>
            <hr>
            <ul class="nav nav-pills  flex-column py-3 mb-auto">
                <a href="#" class="nav-link text-white">
                    <i class="fa-solid fa-house"></i>
                    Home
                </a>
                </li>
                <li>
                    <a href="/AdminDash" class="nav-link text-white">
                        <i class="fa-solid fa-gauge"></i>
                        Dashboard
                    </a>
                </li>
                <li>
                    <a href="/courses" class="nav-link text-white">
                        <i class="fa-solid fa-table-cells-large"></i>
                        Modules
                    </a>
                </li>
                <li>
                    <a href="/student" class="nav-link text-white">
                        <i class="fa-solid fa-users-viewfinder"></i>
                        Students
                    </a>
                </li>
                <li>
                    <a href="#" class="nav-link text-white">
                        <i class="fa-solid fa-comments"></i>
                        Feedback
                    </a>
                </li>
                <li>
                    <a href="/first" class="nav-link text-white">
                        <i class="fa fa-sign-out" aria-hidden="true"></i>
                        Sign Out
                    </a>
                </li>
            </ul>
            <hr>
            <div class="dropdown">
                <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="fa-solid fa-user-secret mx-3  bi w-40 h-40"></i>
                    <strong>Admin</strong>
                </a>
                <ul class="dropdown-menu dropdown-menu-primary text-small shadow" aria-labelledby="dropdownUser1">

                    <li><a class="dropdown-item" href="#"><i class="fa-solid fa-key me-2"></i>Change Password</a></li>
                    <li>
                        <hr class="dropdown-divider">
                    </li>
                    <li><a class="dropdown-item" href="#"><i class="fa-solid fa-right-from-bracket me-2"></i>Sign out</a></li>
                </ul>
            </div>
        </div>

        <div class="invent">
            <div class="inventory detail">
                <div class="detail-header">
                    <h1 class="fs-3">Lessons</h1>
                </div>
                <div id="idcon">
                    <table id="tab">
                        <tr>
                            <th>Title</th>
                            <th>Module ID</th>
                            <th>Category</th>
                            <th>Grade Level</th>
                            <th>Date Added</th>
                            <th>Action </th>
                        </tr>
                        @foreach($modules as $module)
                        <tr>
                            <td>{{ $module->title }}</td>
                            <td>{{ $module->subject }}</td> 
                            <td>{{ $module->grade_level }}</td>
                            <td>{{ $module->module_id }}</td>
                            <td>{{ $module->published_date }}</td>
                            <td>Action</td>
                        </tr>
                        @endforeach
                    </table>
                </div>
            </div>

            <div class="Add">
                <form action="{{ route('modules.store') }}" method='post'>
                @csrf
                    <h1>Add Module</h1>
                    <input type="text" class="field" name="title" id="Title" placeholder="Title">
                    <input type="text" class="field" name="subject" id="Module_Id" placeholder="Module ID">
                    <select name="module_id"  id="Categories" class="ptype">
                        <option value="Categories" selected>Categories</option>
                        <option value="Stories">Stories</option>
                        <option value="English">English</option>
                        <option value="Science">Science</option>
                        <option value="Math">Math</option>
                        <option value="Filipino">Filipino</option>
                    </select>
                    <select name="type" id="GradeLevel" class="ptype">
                        <option value="Grade Level" selected>Grade Level</option>
                        <option value="Kinder">Kinder</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                    </select>
                    <input type="date" name="published_date" id="date">
                    <input type="text" name="is_published">
                    <br>
                    <br>
                    <button type="submit" class="send" id="submit" onclick="tabRow()">Submit</button>
                </form>
            </div>
    </main>


    <!-- JavaScript Bundle with Popper -->
    <script src="https://kit.fontawesome.com/f2da3bba74.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>


    <script>
        (function() {
            'use strict'
            var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
            tooltipTriggerList.forEach(function(tooltipTriggerEl) {
                new bootstrap.Tooltip(tooltipTriggerEl)
            })
        })()

        function delRow(btn) {
            var row = btn.parentNode.parentNode;
            row.parentNode.remove(row);
        }

        function tabRow() {
            let Tab = document.querySelector("#tab");
            let Title = document.querySelector("#Title");
            let Module_Id = document.querySelector("#Module_Id");
            let GradeLevel = document.querySelector("#GradeLevel");
            let Date = document.querySelector("#date");
            let File = document.querySelector("#File");
            let Categories = document.querySelector("#Categories");


            let title = Title.value;
            let Gl = GradeLevel.options[GradeLevel.selectedIndex].text;
            let module_Id = Module_Id.value;
            let date = Date.value;
            let file = File.value;
            let categories = Categories.value;

            let template =
                `<tr>
      <td>${title}</td>
      <td>${file}</td>
      <td>${module_Id}</td>
      <td>${categories }</td>
      <td>${Gl}</td>
      <td>${date}</td>
      <td><span class="trash"><i class="fa-solid fa-trash-can text-dark" onclick="delRow(this)"></i></span></td>
      </tr>`;

            Tab.innerHTML += template;
        }
    </script>

</body>

</html>