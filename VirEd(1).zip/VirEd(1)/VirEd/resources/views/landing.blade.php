<!DOCTYPE html>
<html lang="en">
@extends('layouts.app')
@section('content')

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>
        <link rel="icon" href="/img/logo.jpg">
        <link rel="stylesheet" href="{{ asset('css/landing.css') }}">
        <title>VirEd Landing Page</title>
        <style>
            header nav {
                background: #3fafff;
                display: flex;
                align-items: center;
                border-bottom: var(--border);
                top: 0;
                left: 0;
                right: 0;
                z-index: 1000;
                text-shadow: #000000, 10px;
            }

            nav img {
                max-width: 10rem;
                max-height: 10rem;
                border-radius: 100%;
                /* margin:0.5rem 3rem 0.3rem 8rem; */
                margin: 2.5rem 2.5rem -3.6rem 8rem;
            }

            nav ul li {
                display: inline-block;


            }

            nav ul li a {
                color: rgb(0, 0, 0);
                padding: 0 1.9rem 0 2.3rem;
                font-size: 2.2rem;
                font-weight: bold;
                font-family: 'Acme', sans-serif;
                float: left;
                display: block;
                text-align: center;
                padding: 14px;
                text-decoration: none;
            }

            nav ul li:hover {
                font-size: 1.4rem;
                color: var(--main-color);
                border-bottom: .1rem solid var(--main-color);
                padding-bottom: .5rem;
            }

            header nav .search-form {
                background: #ffffff;
                width: 45rem;
                height: 4.4rem;
                display: flex;
                align-items: center;
                border-radius: 5px;
                padding: 0 0 0 1.2rem;
                margin: 0 0 0 6rem;

            }

            header nav .search-form input {
                font-size: 1.4rem;
                width: 100%;
                text-transform: none;
                color: var(--black);
                border: none;
                outline: none;

            }

            header nav .fa-search {
                color: var(--black);
                cursor: pointer;
                font-size: 2.5rem;
                margin: 0.2rem 0.5rem 0 0;
            }

            header nav .user_icon .fa-user {
                font-size: 3.5rem;
                margin: 0 0 0 2.3rem;
            }
        </style>
    </head>

    <body>

        <header>
            <nav>
                <a href="/landing"><img src="/img/logo.jpg" alt="logo"></a>
                <ul>
                    <li><a href="/landing">Home</a></li>
                    <li><a href="/library">Library</a></li>
                    <li><a href="/quizzes">Quizzes</a></li>
                    <li><a href="/contacts">Contact</a></li>
                    <li><a href="/blogs">Blogs</a></li>


                </ul>
                <div class="search-form">
                    <input type="search" id="search-box" placeholder="Search here...">
                    <label for="search-box" class="fas fa-search"></label>
                </div>

        </header>

        {{-- <div class="login-form-container">

            <div id="close-login-btn" class="fas fa-times"></div>

            <form action="/homepage">
                <h3>sign in</h3>
                <span>username</span>
                <input type="email" name="" class="box" placeholder="enter your email" id="">
                <span>password</span>
                <input type="password" name="" class="box" placeholder="enter your password" id="">
                <div class="checkbox">
                    <input type="checkbox" name="" id="remember-me">
                    <label for="remember-me"> remember me</label>
                </div>
                <input type="submit" value="sign in" class="btn">
                <!-- <p>forget password ? <a href="#">click here</a></p> -->
                <p>don't have an account ? <a href="#">create one</a></p>
            </form>

        </div> --}}

        <!-- home section starts  -->

        <section class="home" id="home">

            <div class="row">

                <div class="content">
                    <h3 style="font-family: Dancing Script;">A key to Early Education with one Swipe</h3>
                    <p>Education is the key to all the locked doors of the unknown!</p><br>
                    <p>Why is it important to be educated?
                        Being educated helps people to judge any situation and make the right decision. It also broadens
                        ones perspective and makes one knowledgeable, which is essential for their personal and professional
                        growth in future.</p>
                    <a href="/library" class="btn">Start Learning</a>
                </div>

                <div class="swiper books-slider">
                    <div class="swiper-wrapper">
                        <a href="#" class="swiper-slide"><img src="/img/home.png" alt=""></a>
                        <a href="#" class="swiper-slide"><img src="/img/home.png" alt=""></a>
                        <a href="#" class="swiper-slide"><img src="/img/home.png" alt=""></a>
                        <a href="#" class="swiper-slide"><img src="/img/home.png" alt=""></a>
                        <a href="#" class="swiper-slide"><img src="/img/home.png" alt=""></a>
                        <a href="#" class="swiper-slide"><img src="/img/home.png" alt=""></a>
                    </div>
                </div>
            </div>
        </section>

        <!-- home section ense  -->

        <!-- icons section starts  -->

        <section class="icons-container">

            <div class="icons">
                <i class="fa fa-question" aria-hidden="true"></i>
                <div class="content">
                    <h3>Join Quizzes</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                </div>
            </div>

            <div class="icons">
                <i class="fa fa-book" aria-hidden="true"></i>
                <div class="content">
                    <h3>Go to Library</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                </div>
            </div>

            <div class="icons">
                <i class="fa fa-bookmark" aria-hidden="true"></i>
                <div class="content">
                    <h3>Read blogs</h3>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                </div>
            </div>
        </section>

        <!-- icons section ends -->

        <!-- featured section starts  -->

        <section class="featured" id="featured">

            <h1 class="heading"> <span>featured books</span> </h1>

            <div class="swiper featured-slider">

                <div class="swiper-wrapper">

                    <div class="swiper-slide box">
                        <div class="image">
                            <img src="/img/CoverB.png" alt="">
                        </div>
                        <div class="content">
                            <h3>English books</h3>
                            <a href="/EnglishExtend" class="btn">Start Reading</a>
                        </div>
                    </div>

                    <div class="swiper-slide box">
                        <div class="image">
                            <img src="/img/CoverB.png" alt="">
                        </div>
                        <div class="content">
                            <h3>Math books</h3>
                            <a href="/math" class="btn">Start Reading</a>
                        </div>
                    </div>

                    <div class="swiper-slide box">
                        <div class="image">
                            <img src="/img/CoverB.png" alt="">
                        </div>
                        <div class="content">
                            <h3>Science books</h3>
                            <a href="/science" class="btn">Start Reading</a>
                        </div>
                    </div>
                    <div class="swiper-slide box">
                        <div class="image">
                            <img src="/img/CoverB.png" alt="">
                        </div>
                        <div class="content">
                            <h3>Filipino books</h3>
                            <a href="/filipino" class="btn">Start Reading</a>
                        </div>
                    </div>

                    <div class="swiper-slide box">
                        <div class="image">
                            <img src="/img/CoverB.png" alt="">
                        </div>
                        <div class="content">
                            <h3>Story books</h3>
                            <a href="/stories" class="btn">Start Reading</a>
                        </div>
                    </div>



                </div>

                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>

            </div>

        </section>

        <!-- featured section ends -->

        <!-- arrivals section starts  -->

        <section class="arrivals" id="arrivals">

            <h1 class="heading"> <span>Join Quizzes</span> </h1>

            <div class="swiper arrivals-slider">

                <div class="swiper-wrapper">

                    <a href="quizzes" class="swiper-slide box">
                        <div class="image">
                            <img src="/img/CoverB.png" alt="">
                        </div>
                        <div class="content">
                            <h3>English</h3>

                        </div>
                    </a>

                    <a href="quizzes" class="swiper-slide box">
                        <div class="image">
                            <img src="/img/CoverB.png" alt="">
                        </div>
                        <div class="content">
                            <h3>Math</h3>

                        </div>
                    </a>

                    <a href="quizzes" class="swiper-slide box">
                        <div class="image">
                            <img src="/img/CoverB.png" alt="">
                        </div>
                        <div class="content">
                            <h3>Science</h3>

                        </div>
                    </a>

                    <a href="quizzes" class="swiper-slide box">
                        <div class="image">
                            <img src="/img/CoverB.png" alt="">
                        </div>
                        <div class="content">
                            <h3>Filipino</h3>

                        </div>
                    </a>

                    <a href="quizzes" class="swiper-slide box">
                        <div class="image">
                            <img src="/img/CoverB.png" alt="">
                        </div>
                        <div class="content">
                            <h3>Araling Panlipunan</h3>

                        </div>
                    </a>

                </div>

            </div>

            <div class="swiper arrivals-slider">

                <div class="swiper-wrapper">

                    <a href="quizzes" class="swiper-slide box">
                        <div class="image">
                            <img src="/img/CoverB.png" alt="">
                        </div>
                        <div class="content">
                            <h3>TLE</h3>


                        </div>
                    </a>

                    <a href="quizzes" class="swiper-slide box">
                        <div class="image">
                            <img src="/img/CoverB.png" alt="">
                        </div>
                        <div class="content">
                            <h3>Edukasyong Pantahanan at Pangkabuhayan (EPP) </h3>

                        </div>
                    </a>

                    <a href="quizzes" class="swiper-slide box">
                        <div class="image">
                            <img src="/img/CoverB.png" alt="">
                        </div>
                        <div class="content">
                            <h3>HELE</h3>

                        </div>
                    </a>

                    <a href="quizzes" class="swiper-slide box">
                        <div class="image">
                            <img src="/img/CoverB.png" alt="">
                        </div>
                        <div class="content">
                            <h3>Edukasyon sa Pagpapakatao (EsP)</h3>

                        </div>
                    </a>

                    <a href="quizzes" class="swiper-slide box">
                        <div class="image">
                            <img src="/img/CoverB.png" alt="">
                        </div>
                        <div class="content">
                            <h3>Mother Tongue</h3>

                        </div>
                    </a>

                </div>

            </div>

        </section>

        <!-- arrivals section ends -->
        <!-- reviews section starts  -->

        <section class="reviews" id="reviews">

            <h1 class="heading"> <span>Our Team</span> </h1>

            <div class="swiper reviews-slider">

                <div class="swiper-wrapper">
                    <div class="swiper-slide box">
                        <img src="/img/team1.png" alt="">
                        <h3>Toquero</h3>
                        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Aspernatur nihil ipsa placeat. Aperiam
                            at sint, eos ex similique facere hic.</p>
                    </div>
                    <div class="swiper-slide box">
                        <img src="/img/team2.png" alt="">
                        <h3>Ypil</h3>
                        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Aspernatur nihil ipsa placeat. Aperiam
                            at sint, eos ex similique facere hic.</p>
                    </div>

                    <div class="swiper-slide box">
                        <img src="/img/team3.png" alt="">
                        <h3>Reambonanza</h3>
                        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Aspernatur nihil ipsa placeat. Aperiam
                            at sint, eos ex similique facere hic.</p>
                    </div>

                    <div class="swiper-slide box">
                        <img src="/img/team4.png" alt="">
                        <h3>Tano</h3>
                        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Aspernatur nihil ipsa placeat. Aperiam
                            at sint, eos ex similique facere hic.</p>
                    </div>

                </div>

            </div>

        </section>

        <!-- reviews section ends -->

        <!-- blogs section starts  -->

        <section class="blogs" id="blogs">

            <h1 class="heading"> <span>our blogs</span> </h1>

            <div class="swiper blogs-slider">

                <div class="swiper-wrapper">

                    <div class="swiper-slide box">
                        <div class="image">
                            <img src="/img/blog1.jpg" alt="">
                        </div>
                        <div class="content">
                            <h3>Build your understanding of how young children learn</h3>

                            <a href="/blogs" class="btn">Learn more</a>
                        </div>
                    </div>

                    <div class="swiper-slide box">
                        <div class="image">
                            <img src="/img/blog2.jpg" alt="">
                        </div>
                        <div class="content">
                            <h3>Understand how play stimulates a child’s natural curiosity to learn.</h3>

                            <a href="/blogs" class="btn">Learn more</a>
                        </div>
                    </div>

                    <div class="swiper-slide box">
                        <div class="image">
                            <img src="/img/blog3.jpg" alt="">
                        </div>
                        <div class="content">
                            <h3>Talk to the children and encourage them.</h3>

                            <a href="/blogs" class="btn">Learn more</a>
                        </div>
                    </div>

                    <div class="swiper-slide box">
                        <div class="image">
                            <img src="/img/blog4.jpg" alt="">
                        </div>
                        <div class="content">
                            <h3>Observe and challenge at the right level for the individual child.</h3>

                            <a href="/blogs" class="btn">Learn more</a>
                        </div>
                    </div>

                    <div class="swiper-slide box">
                        <div class="image">
                            <img src="/img/blog5.jpg" alt="">
                        </div>
                        <div class="content">
                            <h3> Tune in to the child and empathise with them.</h3>

                            <a href="/blogs" class="btn">Learn more</a>
                        </div>
                    </div>

                </div>

            </div>

        </section>

        <!-- blogs section ends -->

        <!-- newsletter section starts -->

        <section class="newsletter">

            <form action="/homepage">
                <h3>subscribe to our newsletter</h3>
                <input type="email" name="" placeholder="enter your email" id="" class="box">
                <input type="submit" value="subscribe" class="btn">
            </form>

        </section>

        <!-- newsletter section ends -->

        <!-- footer section starts  -->

        <section class="footer">

            <div class="box-container">

                <div class="box">
                    <h3>quick links</h3>
                    <a href="/landing"> <i class="fas fa-arrow-right"></i> home </a>
                    <a href="/library"> <i class="fas fa-arrow-right"></i> Library </a>
                    <a href="/contact"> <i class="fas fa-arrow-right"></i> Contacts </a>
                    <a href="/blogs"> <i class="fas fa-arrow-right"></i> Blogs </a>
                </div>

                <div class="box">
                    <h3>contact info</h3>
                    <a href="#"> <i class="fas fa-phone"></i> +123-456-7890 </a>
                    <a href="#"> <i class="fas fa-phone"></i> +111-222-3333 </a>
                    <a href="#"> <i class="fas fa-envelope"></i> VirEd@gmail.com </a>
                    <a href="#"> <i class="fas fa-envelope"></i> VirEdPhilippines </a>
                </div>

                <div class="box">
                    <h3>SNS</h3>
                    <a href="https://facebook.com"> <i class="fab fa-facebook-f"></i> facebook </a>
                    <a href="https://twitter.com"> <i class="fab fa-twitter"></i> twitter </a>
                    <a href="https://instagram.com"> <i class="fab fa-instagram"></i> instagram </a>
                    <a href="https://linkedin.com"> <i class="fab fa-linkedin"></i> linkedin </a>
                </div>
            </div>

            <div class="box">
                <footer style="color: white ;float: right;">
                    <p>© Copyright 2022 Vired</p>
                </footer>
            </div>
        </section>
    </body>
    <script src="{{ asset('js/landing.js') }}"></script>
@endsection

</html>
