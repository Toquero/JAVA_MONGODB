<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="/img/logo.jpg">
    <script src="https://code.jquery.com/jquery-3.2.1.js"></script>
    <title>First Page</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Acme&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Acme', sans-serif;
        }

        body {
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background-image: url(/img/10.jpg);
            background-size: cover;
            -webkit-backdrop-filter: blur(1px);
            backdrop-filter: blur(1px);
        }

        .muragForm {
            padding: 6%;
            position: relative;
            width: 30%;
            height: 40%;
            background: rgb(247, 243, 246);
            border-style: none;
            box-shadow: #faa469 0 -12px 6px 5px inset;
            border-radius: 40px;
            overflow: hidden;
            margin: 0 20px;
        }


        h2 {
            font-size: 28px;
            color: black;
        }

        .bttn {
            font-family: 'Acme', sans-serif;
            margin-left: 10%;
            background-color:#faa469;
            border-radius: 40em;
            border-style: none;
            box-shadow: rgb(17, 66, 136) 0 -12px 6px inset;
            box-sizing: border-box;
            color: #000000;
            cursor: pointer;
            appearance: none;
            display: inline-block;
            font-size: 15px;
            font-weight: 700;
            letter-spacing: -.24px;
            outline: none;
            padding: 1rem 1.3rem;
            quotes: auto;
            align-items: center;
            text-align: center;
            text-decoration: none;
            transition: all .15s;
            user-select: none;
            -webkit-user-select: none;
            touch-action: manipulation;
            width: 35%;
            display: inline-block;
        }

        .bttn:hover {
            background-color: #0a9d87;
        }


        button {
            background-color:#faa469;
            color: #000000;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            cursor: pointer;
            width: 100%;
        }



        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgb(0, 0, 0);
            background-color: rgba(0, 0, 0, 0.4);
        }
    </style>
</head>

<body>
    <div class="muragForm">
        <h2>Kids-E | Login Form</h2>
        <div class="form">
            @if (Route::has('login'))
                <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
                    @auth
                        <a href="{{ url('/home') }}" class="text-sm text-gray-700 dark:text-gray-500 underline"><button>Back to Home</button></a>
                        <a href="{{ url('Admin') }}" class="text-sm text-gray-700 dark:text-gray-500 underline"><button>Log in as Admin </button></a>
                    @else
                        <a href="{{ route('login') }}" class="text-sm text-gray-700 dark:text-gray-500 underline"><button>Log in as User</button></a>
                        <a href="{{ route('login') }}" class="text-sm text-gray-700 dark:text-gray-500 underline"><button>Log in as Admin</button></a>


                        {{-- @if (Route::has('register'))
                            <a href="{{ route('register') }}"
                                class="ml-4 text-sm text-gray-700 dark:text-gray-500 underline">Register</a>
                        @endif --}}
                    @endauth
                </div>
            @endif
        </div>
{{-- 
        <div class="form">
            <h2>Kids-E | Login Form</h2>
            <hr>
            <br>
            <span class="text"><b>Login as</b></span>
            <br><br>

            <a href="{{ url('Admin') }}">
                <button class="bttn " role="button">Admin</button>
            </a>

            <a href="{{ url('login') }}">
                <button class="bttn" role="button">User </button>
            </a>

        </div> --}}
    </div>
</body>

</html>
