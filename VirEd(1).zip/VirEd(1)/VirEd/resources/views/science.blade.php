<!DOCTYPE html>
<html>
 
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="img/children1.png">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <title>Math Category</title>
 
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Acme&display=swap');
    body {
        font-family: 'Acme', sans-serif;
        background: #faa469;
    }
 
    #myImg {
        border-radius: 5px;
        cursor: pointer;
        transition: 0.3s;
       
       
   
    }
 
    #myImg:hover {
        opacity: 0.7;
    }
 
    .modal {
        display: none;
        position: fixed;
        z-index: 1;
        padding-top: 100px;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto;
        background-color:gray;
       
    }
 
    /* Modal Content (image) */
    .modal-content {
        margin: auto;
        display: block;
        width: 80%;
        max-width: 700px;
    }
 
    /* Caption of Modal Image */
    #caption {
        margin: auto;
        display: block;
        width: 80%;
        max-width: 700px;
        text-align: center;
        color: #ccc;
        padding: 10px 0;
        height: 150px;
    }
 
    /* Add Animation */
    .modal-content,
    #caption {
        -webkit-animation-name: zoom;
        -webkit-animation-duration: 0.6s;
        animation-name: zoom;
        animation-duration: 0.6s;
    }
 
    @-webkit-keyframes zoom {
        from {
            -webkit-transform: scale(0)
        }
 
        to {
            -webkit-transform: scale(1)
        }
    }
 
    @keyframes zoom {
        from {
            transform: scale(0)
        }
 
        to {
            transform: scale(1)
        }
    }
 
    /* The Close Button */
    .close {
        position: absolute;
        top: 15px;
        right: 35px;
        color: red;
        font-size: 60px;
        font-weight: bold;
        transition: 0.3s;
 
    }
 
    .close:hover,
    .close:focus {
        color: red;
        text-decoration: none;
        cursor: pointer;
    }
 
    /* 100% Image Width on Smaller Screens */
    @media only screen and (max-width: 700px) {
        .modal-content {
            width: 100%;
        }
    }
 
    .btn {
    margin-top: 1rem;
    display: inline-block;
    padding:1% ;
    border-radius: .5rem;
    border:black solid 2px;
    color: black;
    background: white;
    font-size:large;
    cursor: pointer;
    font-weight: 500;
    }
 
    .btn:hover {
        background: #09adff;
       
    }
    .container{
        max-width: 400px;
        display:block;
        position: relative;
        justify-items: center;
        float:left;
        margin-left:20%;
        margin-top: 2%;
        border:3px solid black;
    }
    .myCaroussel{
        display: block;
        justify-content: center;
    }
    .prev, .next {
        cursor: pointer;
        position: absolute;
        top: 50%;
        width: auto;
        margin-top: -22px;
        padding: 16px;
        color: white;
        font-weight: bold;
        font-size: 18px;        
        transition: 0.6s ease;
        border-radius: 0 3px 3px 0;
        user-select: none;
    }
    .text {
        color: #f2f2f2;
        font-size: 15px;
        padding: 8px 12px;
        position: absolute;
        bottom: 8px;
        width: 100%;
        text-align: center;
    }
    .dot {
        cursor: pointer;
        height: 15px;
        width: 15px;
        margin: 0 2px;
        background-color: #bbb;
        border-radius: 50%;
        display: inline-block;
        transition: background-color 0.6s ease;
    }
    h3{
        color:black;
        padding-left: 2%;
        padding-right: 2%;
    }
 
    </style>
</head>
 
<body>
<center>
        <h2>Science Category</h2>
        <h3> Teaching kids how to manage their finances is one of the most important lessons you can impart them as they
            grow. Fostering a love of Filipino in your child instills with them a sense of pride and belongingness, and is
            important to our identity as a people.</h3>
 
        <div class="container">
            <div id="myCarousel" class="carousel slide" data-ride="carousel">
                <!-- Indicators -->
                <ol class="carousel-indicators">
                <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                <li data-target="#myCarousel" data-slide-to="1"></li>
                <li data-target="#myCarousel" data-slide-to="2"></li>
                </ol>
 
                <!-- Wrapper for slides -->
                <div class="carousel-inner">
 
                <div class="item active">
                    <img id="myImg"
                        src="https://www.comprehension-worksheets.com/wp-content/uploads/2015/08/free-life-science-reading-comprehension-fish.jpg"
                        alt="" style="width:100%;max-width:300px; margin-left:3%;padding:5%;">
                    <div class="carousel-caption">
                        <h3>The Ant and the Dove</h3>
                    </div>
                </div>
 
                <div class="item">
                    <img id="myImg1" src="https://i.pinimg.com/originals/75/c3/40/75c340ae804d0c5109194130467e9648.jpg" alt=""
                        style="width:100%;max-width:300px; margin-left:3%;padding:5%;">
                    <div class="carousel-caption">
                        <h3>The Lion and the Cows</h3>
                    </div>
                </div>
               
                <div class="item">
                    <img id="myImg2"
                        src="https://www.comprehension-worksheets.com/wp-content/uploads/2015/08/free-life-science-reading-comprehension-plants.jpg"
                        alt="" style="width:100%;max-width:300px; margin-left:3%;padding:5%;">
                    <div class="carousel-caption">
                        <h3>The Thirsty Cow</h3>
                    </div>
                </div>
 
                <div class="item">
                    <img id="myImg3" src="https://i.pinimg.com/550x/bc/f2/1d/bcf21d772045a4f1eb82f9b5138f64f0.jpg" alt=""
                        style="width:100%;max-width:300px; margin-left:3%;padding:5%;">
                    <div class="carousel-caption">
                        <h3>The Ant and the Grasshopper</h3>
                    </div>
                </div>
           
                <div class="item">
                    <img id="myImg4" src="https://i.pinimg.com/originals/75/c3/40/75c340ae804d0c5109194130467e9648.jpg" alt=""
                        style="width:100%;max-width:300px; margin-left:3%;padding:5%;">
                    <div class="carousel-caption">
                        <h3>The Lion and the Cows</h3>
                    </div>
                </div>
 
                <div class="item">
                    <img id="myImg5"
                        src="https://www.comprehension-worksheets.com/wp-content/uploads/2015/08/free-life-science-reading-comprehension-plants.jpg"
                        alt="" style="width:100%;max-width:300px; margin-left:3%;padding:5%;">
                    <div class="carousel-caption">
                        <h3>The Thirsty Cow</h3>
                    </div>
                </div>
             </div>
            </div>
 
 
<!-- Left and right controls -->
<a class="left carousel-control" href="#myCarousel" data-slide="prev">
<span class="glyphicon glyphicon-chevron-left"style="color:black"></span>
<span class="sr-only">Previous</span>
</a>
<a class="right carousel-control" href="#myCarousel" data-slide="next">
<span class="glyphicon glyphicon-chevron-right"style="color:black;"></span>
<span class="sr-only">Next</span>
</a>
</div>
</div>
    <!-- The Modal -->
    <div id="myModal" class="modal">
        <span class="close">&times;</span>
        <img class="modal-content" id="img01">
        <div id="caption"></div>
    </div>
 
    <script>
    // Get the modal
    var modal = document.getElementById("myModal");
 
    // Get the image and insert it inside the modal - use its "alt" text as a caption
    var img = document.getElementById("myImg");
    var modalImg = document.getElementById("img01");
    var captionText = document.getElementById("caption");
    img.onclick = function() {
        modal.style.display = "block";
        modalImg.src = this.src;
        captionText.innerHTML = this.alt;
    }
 
    var img = document.getElementById("myImg1");
    var modalImg = document.getElementById("img01");
    var captionText = document.getElementById("caption");
    img.onclick = function() {
        modal.style.display = "block";
        modalImg.src = this.src;
        captionText.innerHTML = this.alt;
    }
 
    var img = document.getElementById("myImg2");
    var modalImg = document.getElementById("img01");
    var captionText = document.getElementById("caption");
    img.onclick = function() {
        modal.style.display = "block";
        modalImg.src = this.src;
        captionText.innerHTML = this.alt;
    }
 
    var img = document.getElementById("myImg3");
    var modalImg = document.getElementById("img01");
    var captionText = document.getElementById("caption");
    img.onclick = function() {
        modal.style.display = "block";
        modalImg.src = this.src;
        captionText.innerHTML = this.alt;
    }
 
    var img = document.getElementById("myImg4");
    var modalImg = document.getElementById("img01");
    var captionText = document.getElementById("caption");
    img.onclick = function() {
        modal.style.display = "block";
        modalImg.src = this.src;
        captionText.innerHTML = this.alt;
    }
 
    var img = document.getElementById("myImg5");
    var modalImg = document.getElementById("img01");
    var captionText = document.getElementById("caption");
    img.onclick = function() {
        modal.style.display = "block";
        modalImg.src = this.src;
        captionText.innerHTML = this.alt;
    }
 
    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];
 
    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
        modal.style.display = "none";
    }
    </script>
       <div>
                <img src="img/children1.png" class="children1" alt="" style="margin-left:5%; margin-top:.5%;width:30%">
            </div>
    <br><br>
<center>
    <a href="/library"><button class="btn">Back</button></a><center>
 
    </body>
</html>
