<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="img/children1.png">
    <title>EnglishExtend | Page</title>
</head>
<style>
@import url('https://fonts.googleapis.com/css2?family=Acme&display=swap');

* {
    margin: 0;
    padding: 0;
    font-family: 'Acme', sans-serif;
}
body {
    background: #23ccff;
}

/* modal content styles */
.modal-content-wrapper {
    max-width: 1400px;
    width: 90%;
    display: flex;
    margin: auto;
    flex-wrap: wrap;
    justify-content: space-between;
    padding: 70px 0;
}

.modal-content-wrapper .image-modal-content {
    flex: 0 0 30%;
    cursor: pointer;
    transition: 300ms ease-out;
    margin-right: 20px;
    margin-bottom: 40px;
}

@media (max-width: 992px) {
    .modal-content-wrapper .image-modal-content {
        flex: 0 0 45%;
    }
}

@media (max-width: 550px) {
    .modal-content-wrapper .image-modal-content {
        flex: 0 0 100%;
    }
}

.modal-content-wrapper .image-modal-content:hover {
    transform: scale(1.03);
    transition: 300ms ease-in;
}

.modal-content-wrapper .image-modal-content img {
    width: 100%;
    height: 300px;
    object-fit: cover;
    border-radius: 10px;
    border: 1px solid #222;
}

/* modal popup styles */
.image-modal-popup {
    position: fixed;
    overflow: auto;
    top: 0;
    bottom: 0;
    right: 0;
    left: 0;
    background: rgba(0, 0, 0, 0.8);
    color: #fff;
    animation: 500ms fadeIn;
    display: none;
}

@keyframes fadeIn {
    from {
        opacity: 0;
    }

    to {
        opacity: 1;
    }
}

.image-modal-popup .wrapper {
    display: flex;
    flex-direction: column;
    align-items: center;
    max-width: 1200px;
    margin: auto;
    margin-top: 30px;
    position: relative;
}

.image-modal-popup .description {
    text-align: center;
}

.image-modal-popup img {
    width: 80%;
    max-height: calc(100vh - 150px);
    margin-bottom: 10px;
    cursor: pointer;
}

.image-modal-popup span {
    position: absolute;
    top: 0;
    right: 10px;
    font-size: 4rem;
    color: red;
    cursor: pointer;
}

.image-modal-popup p {
    margin: 5px auto;
    font-size: 1.1rem;
}

.image-modal-popup a {
    margin-bottom: 5px;
    display: inline-block;
    color: #222;
    font-weight: 500;
    text-decoration: none;
    background: #fff;
    margin: 10px 10px;
    padding: 10px 15px;
    border-radius: 6px;
}

.btn {
    margin-top: 1rem;
    display: inline-block;
    padding: .9rem 0rem;
    border-radius: .5rem;
    color: black;
    background: white;
    font-size: 1.0rem;
    cursor: pointer;
    font-weight: 500;
    }

    .btn:hover {
        background: orange;
        
    }
</style>

<body>

    <!--  Content that initiates the modal opening  -->
    <div class="modal-content-wrapper">
        <div class="image-modal-content">
            <img src="https://i.pinimg.com/originals/17/4d/31/174d312f1c5aaaf315a2fd7cb8026402.png"
                data-title="My Cool Title" data-description="This is a super cool description"
                data-url="https://riley.gg/" data-repo="https://github.com/Riley-Brown" alt="Vanilla JS Modal">
        </div>
        <div class="image-modal-content">
            <img src="https://i.pinimg.com/originals/81/9c/94/819c944c032d1c9c1f06800bfba31f07.png"
                data-title="Another Cool Title" data-description="This is also a super Cool description"
                data-url="https://riley.gg/" data-repo="https://github.com/Riley-Brown" alt="Vanilla JS Modal">
        </div>
        <div class="image-modal-content">
            <img src="https://i.ibb.co/rxfK1Zs/The-Hungry-Mouse-Story-Moral-Stories-for-Kids-in-English-Short-Stories-SK-Kids-Time-Sub-Kuch-Web.jpg"
                data-title="My Cool Modal" data-description="What a cool modal wow!" data-url="https://riley.gg/"
                data-repo="https://github.com/Riley-Brown" alt="Vanilla JS Modal">
        </div>
        <div class="image-modal-content">
            <img src="https://i.pinimg.com/474x/53/d9/57/53d957f987a3f9137bc5ca4c092451ff.jpg"
                data-title="My Cool Title" data-description="This is a super Cool Title" data-url="https://riley.gg/"
                data-repo="https://github.com/Riley-Brown" alt="Vanilla JS Modal">
        </div>
        <div class="image-modal-content">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSDEkYx3Lm1IjZs1MsqqIYLncpgilQPbY5Qnxsay-s1ZxI17C2aEktxnRMmNsk4EzQIRtk&usqp=CAU"
                data-title="My Cool Title" data-description="This is a super Cool Title" data-url="https://riley.gg/"
                data-repo="https://github.com/Riley-Brown" alt="Vanilla JS Modal">
        </div>
        <div class="image-modal-content">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQOaGNy5qPG4IBwhyWq8Wt10YCH9FdG9LfRPgX6SeAAb34f7LhltJvZP2nrCrCZRkOnsSw&usqp=CAU"
                data-title="Cool Doggo" data-description="Look at this cool little doggo" data-url="https://riley.gg/"
                data-repo="https://github.com/Riley-Brown" alt="Vanilla JS Modal">
      


    <!-- modal popup (displayed none by default) -->
    <div class="image-modal-popup">
        <div class="wrapper">
            <span>&times;</span>
            <img src="" alt="Image Modal">
            <div class="description">
                <h1>This is placeholder content</h1>
                <p>This content will be overwritten when the modal opens</p>
                <a  class="secondary-link" target="_blank" rel="#"></a>
            </div>
        </div>
    </div>
</body>
<script>
const lightboxImages = document.querySelectorAll('.image-modal-content img');

// dynamically selects all elements inside modal popup
const modalElement = element =>
    document.querySelector(`.image-modal-popup ${element}`);

const body = document.querySelector('body');

// closes modal on clicking anywhere and adds overflow back
document.addEventListener('click', () => {
    body.style.overflow = 'auto';
    modalPopup.style.display = 'none';
});

const modalPopup = document.querySelector('.image-modal-popup');

// loops over each modal content img and adds click event functionality
lightboxImages.forEach(img => {
    const data = img.dataset;
    img.addEventListener('click', e => {
        body.style.overflow = 'hidden';
        e.stopPropagation();
        modalPopup.style.display = 'block';
        modalElement('h1').innerHTML = data.title;
        modalElement('p').innerHTML = data.description;
        modalElement('a').href = data.url;
        modalElement('.secondary-link').href = data.repo;
        modalElement('img').src = img.src;
    });
});
</script>

</html>